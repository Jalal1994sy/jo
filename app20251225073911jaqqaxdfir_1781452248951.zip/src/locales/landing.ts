
export const landingTranslations = {
  nl: {
    navFeatures: "Functies",
    navStats: "Statistieken",
    navHowItWorks: "Hoe het werkt",
    navDriverLogin: "Chauffeur Login",
    navLogin: "Inloggen",

    heroBadge: "Het #1 Taxi Beheerplatform in België",
    heroTitle1: "Beheer uw vloot",
    heroTitle2: "slim en efficiënt",
    heroSubtitle:
      "Een compleet platform voor taxibedrijven — rittracking, chauffeurbeheer, elektronische facturen en geavanceerde rapporten op één plek.",
    heroCta: "Nu gratis starten",
    heroExplore: "Ontdek functies",
    heroBadge1: "100% Veilig",
    heroBadge2: "Compatibel met België",
    heroBadge3: "Snel & Betrouwbaar",

    adSpaceTitle: "Advertentieruimte",
    adSpaceSubtitle:
      "Deze ruimte is klaar voor HTML-campagnes vanuit het beheerpaneel.",

    statDrivers: "Actieve Chauffeurs",
    statCompanies: "Taxibedrijven",
    statTrips: "Voltooide Ritten",
    statSatisfaction: "Klanttevredenheid",

    featuresBadge: "Platform Functies",
    featuresTitle1: "Alles wat u nodig heeft op",
    featuresTitle2: "één plek",
    featuresSubtitle:
      "Een uitgebreid platform speciaal ontworpen voor taxibedrijven in België",

    feature1Title: "Ritbeheer",
    feature1Desc:
      "Volg en beheer alle taxiritten in realtime met nauwkeurige interactieve kaarten.",
    feature2Title: "Geavanceerde Rapporten",
    feature2Desc:
      "Uitgebreide statistieken en rapporten voor dagelijkse en maandelijkse prestatie- en omzetopvolging.",
    feature3Title: "Hoge Beveiliging",
    feature3Desc:
      "Meerlaags authenticatiesysteem dat de bescherming van uw bedrijfs- en chauffeurgegevens garandeert.",
    feature4Title: "Elektronische Facturen",
    feature4Desc:
      "Automatisch facturen aanmaken en verzenden met ondersteuning voor digitale handtekening en archivering.",
    feature5Title: "Directe Meldingen",
    feature5Desc:
      "Slim meldingssysteem dat chauffeurs en managers altijd op de hoogte houdt.",
    feature6Title: "Teambeheer",
    feature6Desc:
      "Beheer chauffeurs, bedrijven en distributeurs vanuit één unified en gebruiksvriendelijk dashboard.",

    pricingBadge: "Abonnementen",
    pricingTitle1: "Kies het plan dat past bij",
    pricingTitle2: "uw groei",
    pricingSubtitle:
      "Klik op een plan om direct via WhatsApp uw aanvraag te versturen.",
    pricingPlan1Name: "Starter",
    pricingPlan1Desc: "1 voertuig + 1 chauffeur",
    pricingPlan1Price: "€49.99 / maand",
    pricingPlan2Name: "Growth",
    pricingPlan2Desc: "2 voertuigen + 2 chauffeurs",
    pricingPlan2Price: "€89.99 / maand",
    pricingPlan3Name: "Pro",
    pricingPlan3Desc: "3e voertuig of 3e chauffeur",
    pricingPlan3Price: "€119.99 / maand",
    pricingMore:
      "Voor meer dan 3 voertuigen of chauffeurs, neem contact met ons op via WhatsApp.",
    pricingCta: "Bestellen via WhatsApp",

    howTitle1: "Hoe werkt",
    howTitle2: "het systeem?",
    howSubtitle: "Drie eenvoudige stappen om te beginnen",
    step1Number: "01",
    step1Title: "Account aanmaken",
    step1Desc:
      "Registreer uw bedrijf en voeg chauffeurgegevens toe in enkele minuten.",
    step2Number: "02",
    step2Title: "Voertuigen instellen",
    step2Desc:
      "Voeg uw voertuigen toe en stel de juiste prijzen in voor elk type.",
    step3Number: "03",
    step3Title: "Start ritten",
    step3Desc:
      "Begin direct met het volgen van ritten en het beheren van facturen.",

    ctaTitle: "Klaar om te beginnen?",
    ctaSubtitle:
      "Sluit u aan bij honderden taxibedrijven die JouwDriver vertrouwen voor hun bedrijfsbeheer",
    ctaButton: "Nu starten",
    ctaBenefit1: "Geen installatiekosten",
    ctaBenefit2: "Gratis technische ondersteuning",
    ctaBenefit3: "Op elk moment opzeggen",

    footerRights: "© 2025 JouwDriver. Alle rechten voorbehouden.",
    footerLocation: "Brussel, België",

    registerTitle: "Chauffeur Registratie",
    registerSubtitle: "Sluit u aan bij het JOUW DRIVER platform",
    step: "Stap",
    of: "van",

    step1RegTitle: "Account aanmaken",
    step1RegSubtitle: "Voer uw e-mailadres en wachtwoord in",
    emailLabel: "E-mailadres",
    emailPlaceholder: "uw@email.be",
    passwordLabel: "Wachtwoord",
    passwordPlaceholder: "Minimaal 6 tekens",
    confirmPasswordLabel: "Wachtwoord bevestigen",
    confirmPasswordPlaceholder: "Herhaal uw wachtwoord",
    sendVerificationCode: "Verificatiecode verzenden",
    verificationCodeLabel: "Verificatiecode",
    verificationCodePlaceholder: "6-cijferige code",
    verificationSentTo: "Code verzonden naar",
    resendCode: "Code opnieuw verzenden",
    resendIn: "Opnieuw verzenden over",
    seconds: "seconden",
    passwordMismatch: "Wachtwoorden komen niet overeen",
    alreadyHaveAccount: "Al een account?",
    loginHere: "Hier inloggen",

    step2RegTitle: "Persoonlijke gegevens",
    step2RegSubtitle: "Vul uw persoonlijke informatie in",
    fullNameLabel: "Volledige naam",
    fullNamePlaceholder: "Voornaam Achternaam",
    phoneLabel: "Telefoonnummer",
    phonePlaceholder: "+32 XXX XX XX XX",
    companyAddressLabel: "Bedrijfsadres",
    companyAddressPlaceholder: "Straat, Nummer, Gemeente",

    step3RegTitle: "Bedrijfsgegevens",
    step3RegSubtitle: "Informatie over uw taxibedrijf",
    companyNameLabel: "Bedrijfsnaam",
    companyNamePlaceholder: "Naam van uw taxibedrijf",
    vatNumberLabel: "BTW-nummer (TVA)",
    vatNumberPlaceholder: "BE0000000000",
    kboNumberLabel: "KBO-nummer",
    kboNumberPlaceholder: "0000.000.000",
    companyEmailLabel: "Bedrijfs e-mail",
    companyEmailPlaceholder: "info@bedrijf.be",
    companyPhoneLabel: "Bedrijfstelefoon",
    companyPhonePlaceholder: "+32 2 XXX XX XX",

    step4RegTitle: "Chiron Configuratie (Optioneel)",
    step4RegSubtitle:
      "Voer uw Chiron testomgeving gegevens in om het proces te versnellen",
    chironSectionTitle: "Chiron API Gegevens",
    chironInfoTitle: "Hoe verkrijgt u uw Chiron gegevens?",
    chironInfoDesc:
      "Bezoek de Chiron-portal van de Vlaamse overheid om uw Client ID en Client Secret te verkrijgen voor de testomgeving.",
    chironPortalButton: "Chiron Portal openen",
    chironClientIdLabel: "Client ID (Testomgeving)",
    chironClientIdPlaceholder: "Uw Chiron Client ID",
    chironClientSecretLabel: "Client Secret (Testomgeving)",
    chironClientSecretPlaceholder: "Uw Chiron Client Secret",
    chironOptionalNote:
      "Deze stap is optioneel. U kunt dit later instellen via uw bedrijfsinstellingen.",
    chironSkipButton: "Deze stap overslaan",

    step5RegTitle: "Voertuiggegevens",
    step5RegSubtitle: "Informatie over uw taxi",
    vehicleBrandLabel: "Merk",
    vehicleBrandPlaceholder: "bijv. Mercedes, Toyota",
    vehicleModelLabel: "Model",
    vehicleModelPlaceholder: "bijv. E-Klasse, Prius",
    plateNumberLabel: "Nummerplaat",
    plateNumberPlaceholder: "1-ABC-123",
    vinLabel: "Chassisnummer (VIN)",
    vinPlaceholder: "17 tekens",
    chironVehicleIdLabel: "Chiron Voertuig ID",
    chironVehicleIdPlaceholder: "Chiron systeem ID",
    chironVehicleIdHelp:
      "Dit ID wordt verstrekt door het Chiron-systeem van de Vlaamse overheid",

    step6RegTitle: "Documenten & Betaling",
    step6RegSubtitle: "Licenties en betalingsinformatie",
    driverLicenseLabel: "Rijbewijsnummer",
    driverLicensePlaceholder: "Rijbewijsnummer",
    tvaNumberLabel: "BTW-nummer (TVA)",
    tvaNumberPlaceholder: "BE0000000000",
    bestuurderspasLabel: "Bestuurderspas nummer",
    bestuurderspasPlaceholder: "Bestuurderspas ID",
    bestuurderspasHelp: "Verplicht voor taxichauffeurs in Brussel",
    paymentSectionTitle: "Betaling",
    paymentSectionDesc:
      "Voltooi de betaling via de onderstaande link om uw registratie te activeren.",
    paymentButton: "Betalen via SumUp",
    paymentConfirm: "Ik heb de betaling voltooid",
    paymentNote: "Na betaling wordt uw aanvraag beoordeeld door ons team.",

    nextButton: "Volgende",
    backButton: "Terug",
    submitButton: "Aanvraag indienen",
    submitting: "Bezig met indienen...",

    successTitle: "Aanvraag ingediend!",
    successMessage:
      "Uw registratie is ontvangen. Ons team zal uw aanvraag beoordelen en u binnen 24-48 uur contacteren.",
    successWhatsapp: "Stuur ook uw gegevens via WhatsApp naar",
    backToHome: "Terug naar startpagina",

    required: "Dit veld is verplicht",
    invalidEmail: "Ongeldig e-mailadres",
    invalidPhone: "Ongeldig telefoonnummer",
    invalidVat: "Ongeldig BTW-nummer (formaat: BE0000000000)",
    invalidKbo: "Ongeldig KBO-nummer",
    minLength: "Minimaal",
    characters: "tekens",
  },
  fr: {
    navFeatures: "Fonctionnalités",
    navStats: "Statistiques",
    navHowItWorks: "Comment ça marche",
    navDriverLogin: "Connexion Chauffeur",
    navLogin: "Se connecter",

    heroBadge: "La plateforme #1 de gestion de taxi en Belgique",
    heroTitle1: "Gérez votre flotte",
    heroTitle2: "intelligemment",
    heroSubtitle:
      "Une plateforme complète pour les entreprises de taxi — suivi des courses, gestion des chauffeurs, factures électroniques et rapports avancés en un seul endroit.",
    heroCta: "Commencer gratuitement",
    heroExplore: "Découvrir les fonctionnalités",
    heroBadge1: "100% Sécurisé",
    heroBadge2: "Compatible Belgique",
    heroBadge3: "Rapide & Fiable",

    adSpaceTitle: "Espace publicitaire",
    adSpaceSubtitle:
      "Cet emplacement est prêt à publier des campagnes HTML depuis le tableau de bord.",

    statDrivers: "Chauffeurs Actifs",
    statCompanies: "Entreprises de Taxi",
    statTrips: "Courses Complétées",
    statSatisfaction: "Satisfaction Client",

    featuresBadge: "Fonctionnalités",
    featuresTitle1: "Tout ce dont vous avez besoin en",
    featuresTitle2: "un seul endroit",
    featuresSubtitle:
      "Une plateforme complète conçue spécialement pour les entreprises de taxi en Belgique",

    feature1Title: "Gestion des Courses",
    feature1Desc:
      "Suivez et gérez toutes les courses de taxi en temps réel avec des cartes interactives précises.",
    feature2Title: "Rapports Avancés",
    feature2Desc:
      "Statistiques et rapports complets pour suivre les performances et les revenus quotidiens et mensuels.",
    feature3Title: "Haute Sécurité",
    feature3Desc:
      "Système d'authentification multicouche garantissant la protection des données de votre entreprise et de vos chauffeurs.",
    feature4Title: "Factures Électroniques",
    feature4Desc:
      "Créez et envoyez des factures automatiquement avec prise en charge de la signature numérique et de l'archivage.",
    feature5Title: "Notifications Instantanées",
    feature5Desc:
      "Système de notifications intelligent qui tient toujours les chauffeurs et les managers informés.",
    feature6Title: "Gestion d'Équipe",
    feature6Desc:
      "Gérez les chauffeurs, les entreprises et les distributeurs depuis un tableau de bord unifié et facile à utiliser.",

    pricingBadge: "Abonnements",
    pricingTitle1: "Choisissez le plan adapté à",
    pricingTitle2: "votre croissance",
    pricingSubtitle:
      "Cliquez sur une offre pour envoyer directement votre demande via WhatsApp.",
    pricingPlan1Name: "Starter",
    pricingPlan1Desc: "1 véhicule + 1 chauffeur",
    pricingPlan1Price: "49,99 € / mois",
    pricingPlan2Name: "Growth",
    pricingPlan2Desc: "2 véhicules + 2 chauffeurs",
    pricingPlan2Price: "89,99 € / mois",
    pricingPlan3Name: "Pro",
    pricingPlan3Desc: "3e véhicule ou 3e chauffeur",
    pricingPlan3Price: "119,99 € / mois",
    pricingMore:
      "Pour plus de 3 véhicules ou chauffeurs, merci de nous contacter via WhatsApp.",
    pricingCta: "Commander via WhatsApp",

    howTitle1: "Comment fonctionne",
    howTitle2: "le système ?",
    howSubtitle: "Trois étapes simples pour commencer",
    step1Number: "01",
    step1Title: "Créer un compte",
    step1Desc:
      "Enregistrez votre entreprise et ajoutez les données des chauffeurs en quelques minutes.",
    step2Number: "02",
    step2Title: "Configurer les véhicules",
    step2Desc:
      "Ajoutez vos véhicules et définissez la tarification appropriée pour chaque type.",
    step3Number: "03",
    step3Title: "Démarrer les courses",
    step3Desc:
      "Commencez immédiatement à suivre les courses et à gérer les factures.",

    ctaTitle: "Prêt à commencer ?",
    ctaSubtitle:
      "Rejoignez des centaines d'entreprises de taxi qui font confiance à JouwDriver pour gérer leur activité",
    ctaButton: "Commencer maintenant",
    ctaBenefit1: "Sans frais d'installation",
    ctaBenefit2: "Support technique gratuit",
    ctaBenefit3: "Annulation à tout moment",

    footerRights: "© 2025 JouwDriver. Tous droits réservés.",
    footerLocation: "Bruxelles, Belgique",

    registerTitle: "Inscription Chauffeur",
    registerSubtitle: "Rejoignez la plateforme JOUW DRIVER",
    step: "Étape",
    of: "sur",

    step1RegTitle: "Créer un compte",
    step1RegSubtitle: "Entrez votre adresse e-mail et mot de passe",
    emailLabel: "Adresse e-mail",
    emailPlaceholder: "votre@email.be",
    passwordLabel: "Mot de passe",
    passwordPlaceholder: "Minimum 6 caractères",
    confirmPasswordLabel: "Confirmer le mot de passe",
    confirmPasswordPlaceholder: "Répétez votre mot de passe",
    sendVerificationCode: "Envoyer le code de vérification",
    verificationCodeLabel: "Code de vérification",
    verificationCodePlaceholder: "Code à 6 chiffres",
    verificationSentTo: "Code envoyé à",
    resendCode: "Renvoyer le code",
    resendIn: "Renvoyer dans",
    seconds: "secondes",
    passwordMismatch: "Les mots de passe ne correspondent pas",
    alreadyHaveAccount: "Déjà un compte ?",
    loginHere: "Se connecter ici",

    step2RegTitle: "Données personnelles",
    step2RegSubtitle: "Remplissez vos informations personnelles",
    fullNameLabel: "Nom complet",
    fullNamePlaceholder: "Prénom Nom",
    phoneLabel: "Numéro de téléphone",
    phonePlaceholder: "+32 XXX XX XX XX",
    companyAddressLabel: "Adresse de l'entreprise",
    companyAddressPlaceholder: "Rue, Numéro, Commune",

    step3RegTitle: "Données de l'entreprise",
    step3RegSubtitle: "Informations sur votre entreprise de taxi",
    companyNameLabel: "Nom de l'entreprise",
    companyNamePlaceholder: "Nom de votre entreprise de taxi",
    vatNumberLabel: "Numéro TVA",
    vatNumberPlaceholder: "BE0000000000",
    kboNumberLabel: "Numéro KBO/BCE",
    kboNumberPlaceholder: "0000.000.000",
    companyEmailLabel: "E-mail de l'entreprise",
    companyEmailPlaceholder: "info@entreprise.be",
    companyPhoneLabel: "Téléphone de l'entreprise",
    companyPhonePlaceholder: "+32 2 XXX XX XX",

    step4RegTitle: "Configuration Chiron (Optionnel)",
    step4RegSubtitle:
      "Entrez vos identifiants Chiron pour accélérer le processus",
    chironSectionTitle: "Identifiants API Chiron",
    chironInfoTitle: "Comment obtenir vos identifiants Chiron ?",
    chironInfoDesc:
      "Visitez le portail Chiron du gouvernement flamand pour obtenir votre Client ID et Client Secret pour l'environnement de test.",
    chironPortalButton: "Ouvrir le portail Chiron",
    chironClientIdLabel: "Client ID (Environnement de test)",
    chironClientIdPlaceholder: "Votre Client ID Chiron",
    chironClientSecretLabel: "Client Secret (Environnement de test)",
    chironClientSecretPlaceholder: "Votre Client Secret Chiron",
    chironOptionalNote:
      "Cette étape est optionnelle. Vous pouvez la configurer plus tard via les paramètres de votre entreprise.",
    chironSkipButton: "Passer cette étape",

    step5RegTitle: "Données du véhicule",
    step5RegSubtitle: "Informations sur votre taxi",
    vehicleBrandLabel: "Marque",
    vehicleBrandPlaceholder: "ex. Mercedes, Toyota",
    vehicleModelLabel: "Modèle",
    vehicleModelPlaceholder: "ex. Classe E, Prius",
    plateNumberLabel: "Plaque d'immatriculation",
    plateNumberPlaceholder: "1-ABC-123",
    vinLabel: "Numéro de châssis (VIN)",
    vinPlaceholder: "17 caractères",
    chironVehicleIdLabel: "ID Véhicule Chiron",
    chironVehicleIdPlaceholder: "ID système Chiron",
    chironVehicleIdHelp:
      "Cet ID est fourni par le système Chiron du gouvernement flamand",

    step6RegTitle: "Documents & Paiement",
    step6RegSubtitle: "Licences et informations de paiement",
    driverLicenseLabel: "Numéro de permis de conduire",
    driverLicensePlaceholder: "Numéro de permis",
    tvaNumberLabel: "Numéro TVA",
    tvaNumberPlaceholder: "BE0000000000",
    bestuurderspasLabel: "Numéro Bestuurderspas",
    bestuurderspasPlaceholder: "ID Bestuurderspas",
    bestuurderspasHelp: "Obligatoire pour les chauffeurs de taxi à Bruxelles",
    paymentSectionTitle: "Paiement",
    paymentSectionDesc:
      "Complétez le paiement via le lien ci-dessous pour activer votre inscription.",
    paymentButton: "Payer via SumUp",
    paymentConfirm: "J'ai complété le paiement",
    paymentNote: "Après paiement, votre demande sera examinée par notre équipe.",

    nextButton: "Suivant",
    backButton: "Retour",
    submitButton: "Soumettre la demande",
    submitting: "Envoi en cours...",

    successTitle: "Demande soumise !",
    successMessage:
      "Votre inscription a été reçue. Notre équipe examinera votre demande et vous contactera dans les 24-48 heures.",
    successWhatsapp: "Envoyez également vos informations via WhatsApp au",
    backToHome: "Retour à l'accueil",

    required: "Ce champ est obligatoire",
    invalidEmail: "Adresse e-mail invalide",
    invalidPhone: "Numéro de téléphone invalide",
    invalidVat: "Numéro TVA invalide (format: BE0000000000)",
    invalidKbo: "Numéro KBO invalide",
    minLength: "Minimum",
    characters: "caractères",
  },
  ar: {
    navFeatures: "المميزات",
    navStats: "الإحصائيات",
    navHowItWorks: "كيف يعمل",
    navDriverLogin: "دخول السائق",
    navLogin: "تسجيل الدخول",

    heroBadge: "منصة إدارة التاكسي #1 في بلجيكا",
    heroTitle1: "أدر أسطولك",
    heroTitle2: "بذكاء وكفاءة",
    heroSubtitle:
      "منصة متكاملة لشركات التاكسي — تتبع الرحلات، إدارة السائقين، الفواتير الإلكترونية والتقارير المتقدمة في مكان واحد.",
    heroCta: "ابدأ مجاناً الآن",
    heroExplore: "استكشف المميزات",
    heroBadge1: "100% آمن",
    heroBadge2: "متوافق مع بلجيكا",
    heroBadge3: "سريع وموثوق",

    adSpaceTitle: "المساحة الإعلانية",
    adSpaceSubtitle:
      "هذه المساحة جاهزة لنشر حملات HTML من لوحة التحكم.",

    statDrivers: "سائق نشط",
    statCompanies: "شركة تاكسي",
    statTrips: "رحلة مكتملة",
    statSatisfaction: "رضا العملاء",

    featuresBadge: "مميزات المنصة",
    featuresTitle1: "كل ما تحتاجه في",
    featuresTitle2: "مكان واحد",
    featuresSubtitle:
      "منصة شاملة مصممة خصيصاً لشركات التاكسي في بلجيكا",

    feature1Title: "إدارة الرحلات",
    feature1Desc:
      "تتبع وإدارة جميع رحلات التاكسي في الوقت الفعلي بخرائط تفاعلية دقيقة.",
    feature2Title: "تقارير متقدمة",
    feature2Desc:
      "إحصائيات وتقارير شاملة لمتابعة الأداء والإيرادات اليومية والشهرية.",
    feature3Title: "أمان عالي",
    feature3Desc:
      "نظام مصادقة متعدد الطبقات يضمن حماية بيانات شركتك وسائقيك.",
    feature4Title: "فواتير إلكترونية",
    feature4Desc:
      "إنشاء وإرسال الفواتير تلقائياً مع دعم التوقيع الرقمي والأرشفة.",
    feature5Title: "إشعارات فورية",
    feature5Desc:
      "نظام إشعارات ذكي يبقي السائقين والمديرين على اطلاع دائم.",
    feature6Title: "إدارة الفريق",
    feature6Desc:
      "أدر السائقين والشركات والموزعين من لوحة تحكم موحدة وسهلة الاستخدام.",

    pricingBadge: "الاشتراكات",
    pricingTitle1: "اختر الخطة المناسبة",
    pricingTitle2: "لنموك",
    pricingSubtitle:
      "انقر على خطة لإرسال طلبك مباشرة عبر واتساب.",
    pricingPlan1Name: "Starter",
    pricingPlan1Desc: "مركبة واحدة + سائق واحد",
    pricingPlan1Price: "49.99€ / شهر",
    pricingPlan2Name: "Growth",
    pricingPlan2Desc: "مركبتان + سائقان",
    pricingPlan2Price: "89.99€ / شهر",
    pricingPlan3Name: "Pro",
    pricingPlan3Desc: "المركبة أو السائق الثالث",
    pricingPlan3Price: "119.99€ / شهر",
    pricingMore:
      "لأكثر من 3 مركبات أو سائقين، تواصل معنا عبر واتساب.",
    pricingCta: "الطلب عبر واتساب",

    howTitle1: "كيف يعمل",
    howTitle2: "النظام؟",
    howSubtitle: "ثلاث خطوات بسيطة للبدء",
    step1Number: "01",
    step1Title: "إنشاء حساب",
    step1Desc:
      "سجّل شركتك وأضف بيانات السائقين في دقائق معدودة.",
    step2Number: "02",
    step2Title: "إعداد المركبات",
    step2Desc:
      "أضف مركباتك وحدد الأسعار المناسبة لكل نوع.",
    step3Number: "03",
    step3Title: "ابدأ الرحلات",
    step3Desc:
      "ابدأ فوراً بتتبع الرحلات وإدارة الفواتير.",

    ctaTitle: "هل أنت مستعد للبدء؟",
    ctaSubtitle:
      "انضم إلى مئات شركات التاكسي التي تثق بـ JouwDriver لإدارة أعمالها",
    ctaButton: "ابدأ الآن",
    ctaBenefit1: "بدون رسوم تثبيت",
    ctaBenefit2: "دعم تقني مجاني",
    ctaBenefit3: "إلغاء في أي وقت",

    footerRights: "© 2025 JouwDriver. جميع الحقوق محفوظة.",
    footerLocation: "بروكسل، بلجيكا",

    registerTitle: "تسجيل السائق",
    registerSubtitle: "انضم إلى منصة JOUW DRIVER",
    step: "خطوة",
    of: "من",

    step1RegTitle: "إنشاء حساب",
    step1RegSubtitle: "أدخل بريدك الإلكتروني وكلمة المرور",
    emailLabel: "البريد الإلكتروني",
    emailPlaceholder: "your@email.be",
    passwordLabel: "كلمة المرور",
    passwordPlaceholder: "6 أحرف على الأقل",
    confirmPasswordLabel: "تأكيد كلمة المرور",
    confirmPasswordPlaceholder: "أعد إدخال كلمة المرور",
    sendVerificationCode: "إرسال رمز التحقق",
    verificationCodeLabel: "رمز التحقق",
    verificationCodePlaceholder: "رمز مكون من 6 أرقام",
    verificationSentTo: "تم إرسال الرمز إلى",
    resendCode: "إعادة إرسال الرمز",
    resendIn: "إعادة الإرسال خلال",
    seconds: "ثانية",
    passwordMismatch: "كلمتا المرور غير متطابقتين",
    alreadyHaveAccount: "لديك حساب بالفعل؟",
    loginHere: "سجّل الدخول هنا",

    step2RegTitle: "البيانات الشخصية",
    step2RegSubtitle: "أدخل معلوماتك الشخصية",
    fullNameLabel: "الاسم الكامل",
    fullNamePlaceholder: "الاسم الأول واسم العائلة",
    phoneLabel: "رقم الهاتف",
    phonePlaceholder: "+32 XXX XX XX XX",
    companyAddressLabel: "عنوان الشركة",
    companyAddressPlaceholder: "الشارع، الرقم، البلدية",

    step3RegTitle: "بيانات الشركة",
    step3RegSubtitle: "معلومات عن شركة التاكسي الخاصة بك",
    companyNameLabel: "اسم الشركة",
    companyNamePlaceholder: "اسم شركة التاكسي",
    vatNumberLabel: "رقم TVA",
    vatNumberPlaceholder: "BE0000000000",
    kboNumberLabel: "رقم KBO",
    kboNumberPlaceholder: "0000.000.000",
    companyEmailLabel: "البريد الإلكتروني للشركة",
    companyEmailPlaceholder: "info@company.be",
    companyPhoneLabel: "هاتف الشركة",
    companyPhonePlaceholder: "+32 2 XXX XX XX",

    step4RegTitle: "إعداد Chiron (اختياري)",
    step4RegSubtitle:
      "أدخل بيانات Chiron لتسريع العملية",
    chironSectionTitle: "بيانات Chiron API",
    chironInfoTitle: "كيف تحصل على بيانات Chiron؟",
    chironInfoDesc:
      "زر بوابة Chiron الحكومية الفلمنكية للحصول على Client ID و Client Secret لبيئة الاختبار.",
    chironPortalButton: "فتح بوابة Chiron",
    chironClientIdLabel: "Client ID (بيئة الاختبار)",
    chironClientIdPlaceholder: "Client ID الخاص بك",
    chironClientSecretLabel: "Client Secret (بيئة الاختبار)",
    chironClientSecretPlaceholder: "Client Secret الخاص بك",
    chironOptionalNote:
      "هذه الخطوة اختيارية. يمكنك إعدادها لاحقاً من إعدادات الشركة.",
    chironSkipButton: "تخطي هذه الخطوة",

    step5RegTitle: "بيانات المركبة",
    step5RegSubtitle: "معلومات عن سيارة التاكسي",
    vehicleBrandLabel: "الماركة",
    vehicleBrandPlaceholder: "مثال: Mercedes، Toyota",
    vehicleModelLabel: "الموديل",
    vehicleModelPlaceholder: "مثال: E-Class، Prius",
    plateNumberLabel: "رقم اللوحة",
    plateNumberPlaceholder: "1-ABC-123",
    vinLabel: "رقم الهيكل (VIN)",
    vinPlaceholder: "17 حرفاً",
    chironVehicleIdLabel: "معرّف مركبة Chiron",
    chironVehicleIdPlaceholder: "معرّف نظام Chiron",
    chironVehicleIdHelp:
      "يُقدَّم هذا المعرّف من نظام Chiron الحكومي الفلمنكي",

    step6RegTitle: "الوثائق والدفع",
    step6RegSubtitle: "التراخيص ومعلومات الدفع",
    driverLicenseLabel: "رقم رخصة القيادة",
    driverLicensePlaceholder: "رقم الرخصة",
    tvaNumberLabel: "رقم TVA",
    tvaNumberPlaceholder: "BE0000000000",
    bestuurderspasLabel: "رقم Bestuurderspas",
    bestuurderspasPlaceholder: "معرّف Bestuurderspas",
    bestuurderspasHelp: "إلزامي لسائقي التاكسي في بروكسل",
    paymentSectionTitle: "الدفع",
    paymentSectionDesc:
      "أكمل الدفع عبر الرابط أدناه لتفعيل تسجيلك.",
    paymentButton: "الدفع عبر SumUp",
    paymentConfirm: "لقد أكملت الدفع",
    paymentNote: "بعد الدفع، سيراجع فريقنا طلبك.",

    nextButton: "التالي",
    backButton: "رجوع",
    submitButton: "إرسال الطلب",
    submitting: "جارٍ الإرسال...",

    successTitle: "تم إرسال الطلب!",
    successMessage:
      "تم استلام تسجيلك. سيراجع فريقنا طلبك ويتواصل معك خلال 24-48 ساعة.",
    successWhatsapp: "أرسل بياناتك أيضاً عبر واتساب إلى",
    backToHome: "العودة إلى الصفحة الرئيسية",

    required: "هذا الحقل مطلوب",
    invalidEmail: "بريد إلكتروني غير صالح",
    invalidPhone: "رقم هاتف غير صالح",
    invalidVat: "رقم TVA غير صالح (الصيغة: BE0000000000)",
    invalidKbo: "رقم KBO غير صالح",
    minLength: "الحد الأدنى",
    characters: "أحرف",
  },
};

export type LandingLanguage = "nl" | "fr" | "ar";
