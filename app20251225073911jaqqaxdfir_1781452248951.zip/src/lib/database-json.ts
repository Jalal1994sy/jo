
function safeJsonClone<T>(value: T): T {
  if (value === undefined) {
    return null as T;
  }

  return JSON.parse(JSON.stringify(value)) as T;
}

export function prepareJsonbValue<T>(value: T): T {
  return safeJsonClone(value);
}

export function prepareUpdatePayload<T extends Record<string, unknown>>(value: T): T {
  const cloned = safeJsonClone(value);
  const entries = Object.entries(cloned || {}).filter(([, currentValue]) => currentValue !== undefined);
  return Object.fromEntries(entries) as T;
}

export function getEntityDisplayName(
  entityType: "company" | "vehicle" | "driver",
  entity: Record<string, unknown> | null | undefined
): string | null {
  if (!entity) {
    return null;
  }

  if (entityType === "company") {
    return String(entity?.name || entity?.email || entity?.id || "");
  }

  if (entityType === "vehicle") {
    return String(
      entity?.plate_number ||
        [entity?.brand, entity?.model].filter(Boolean).join(" ") ||
        entity?.id ||
        ""
    );
  }

  if (entityType === "driver") {
    return String(entity?.full_name || entity?.phone || entity?.id || "");
  }

  return null;
}
