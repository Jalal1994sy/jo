
import { SignJWT, jwtVerify } from "jose";
import { AUTH_CODE, DURATION_EXPIRE_TIME } from "@/constants/auth";
import { ACCESS_TOKEN_EXPIRE_TIME, CACHE_DURATION } from "@/constants/auth";
import { User } from "@/types/auth";
import CrudOperations from "@/lib/crud-operations";
import { JWTPayload } from "./api-utils";

interface CachedAuthCrud {
  usersCrud: CrudOperations;
  sessionsCrud: CrudOperations;
  refreshTokensCrud: CrudOperations;
  userPasscodeCrud: CrudOperations;
  createdAt: number;
}

function getJwtSecret() {
  const secret = process.env.JWT_SECRET;

  if (!secret) {
    throw new Error("JWT_SECRET is not configured");
  }

  return new TextEncoder().encode(secret);
}

let cachedAuthCrud: CachedAuthCrud | null = null;

export async function authCrudOperations(): Promise<{
  usersCrud: CrudOperations;
  sessionsCrud: CrudOperations;
  refreshTokensCrud: CrudOperations;
  userPasscodeCrud: CrudOperations;
}> {
  const now = Date.now();

  if (!cachedAuthCrud || now - cachedAuthCrud.createdAt > CACHE_DURATION * 1000) {
    const adminUserToken = await generateAdminUserToken();

    cachedAuthCrud = {
      usersCrud: new CrudOperations("users", adminUserToken),
      sessionsCrud: new CrudOperations("sessions", adminUserToken),
      refreshTokensCrud: new CrudOperations("refresh_tokens", adminUserToken),
      userPasscodeCrud: new CrudOperations("user_passcode", adminUserToken),
      createdAt: now,
    };
  }

  return cachedAuthCrud;
}

export async function generateAdminUserToken() {
  const adminRole = process.env.SCHEMA_ADMIN_USER || "";

  if (!adminRole) {
    throw new Error("SCHEMA_ADMIN_USER is not configured");
  }

  return generateToken(
    {
      sub: "",
      email: "",
      role: adminRole,
      userType: "admin",
    },
    DURATION_EXPIRE_TIME
  );
}

export async function generateToken(
  user: Omit<User, "isAdmin">,
  expiresIn: number = ACCESS_TOKEN_EXPIRE_TIME
): Promise<string> {
  const adminRole = process.env.SCHEMA_ADMIN_USER || "";

  const payload: Omit<JWTPayload, "iat" | "exp"> = {
    sub: user.sub.toString(),
    email: user.email,
    role: user.role,
    isAdmin: user.role === adminRole,
    userType: user.userType,
  };

  return new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${expiresIn}s`)
    .sign(getJwtSecret());
}

export async function verifyToken(
  token?: string | null
): Promise<{ valid: boolean; code: string; payload: JWTPayload | null }> {
  if (!token) {
    return {
      valid: false,
      code: AUTH_CODE.TOKEN_MISSING,
      payload: null,
    };
  }

  try {
    const { payload } = await jwtVerify(token, getJwtSecret());

    return {
      valid: true,
      code: AUTH_CODE.SUCCESS,
      payload: payload as unknown as JWTPayload,
    };
  } catch (error: any) {
    if (error.code === "ERR_JWT_EXPIRED") {
      return { valid: false, code: AUTH_CODE.TOKEN_EXPIRED, payload: null };
    }

    return { valid: false, code: AUTH_CODE.TOKEN_MISSING, payload: null };
  }
}
