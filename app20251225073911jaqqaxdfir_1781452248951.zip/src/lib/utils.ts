
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

type Primitive = string | number | boolean | null;

const WRAPPER_VALUE_KEYS = [
  "value",
  "displayValue",
  "display_value",
  "displayText",
  "display_text",
  "text",
  "label",
  "name",
  "title",
  "id",
  "raw",
  "rawValue",
  "raw_value",
  "data",
  "content",
  "cellValue",
  "cell_value",
  "columnValue",
  "column_value",
  "stringValue",
  "string_value",
  "numberValue",
  "number_value",
  "booleanValue",
  "boolean_value",
  "dateValue",
  "date_value",
  "timestampValue",
  "timestamp_value",
  "intValue",
  "int_value",
  "floatValue",
  "float_value",
  "decimalValue",
  "decimal_value",
  "formattedValue",
  "formatted_value",
  "innerValue",
  "inner_value",
  "val",
] as const;

const WRAPPER_METADATA_KEYS = [
  "type",
  "dataType",
  "data_type",
  "columnType",
  "column_type",
  "kind",
  "format",
  "formatted",
  "display",
  "label",
  "name",
  "isNull",
  "is_null",
  "nullable",
  "valid",
  "error",
  "status",
  "_type",
  "_meta",
  "meta",
  "metadata",
  "columnName",
  "column_name",
  "column",
  "field",
  "key",
  "rowIndex",
  "row_index",
  "columnIndex",
  "column_index",
  "precision",
  "scale",
  "length",
] as const;

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  if (value === null || typeof value !== "object") {
    return false;
  }

  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

function isPrimitive(value: unknown): value is Primitive {
  return (
    value === null ||
    typeof value === "string" ||
    typeof value === "number" ||
    typeof value === "boolean"
  );
}

function isMetadataKey(key: string) {
  return WRAPPER_METADATA_KEYS.includes(
    key as (typeof WRAPPER_METADATA_KEYS)[number]
  );
}

function getPrimitiveFromValueOf(value: object): Primitive | undefined {
  if (typeof (value as { valueOf?: () => unknown })?.valueOf !== "function") {
    return undefined;
  }

  const resolvedValue = (value as { valueOf: () => unknown }).valueOf();
  return isPrimitive(resolvedValue) ? resolvedValue : undefined;
}

function getPrimitiveFromSymbol(value: object): Primitive | undefined {
  const symbolToPrimitive = (value as {
    [Symbol.toPrimitive]?: (hint: string) => unknown;
  })?.[Symbol.toPrimitive];

  if (typeof symbolToPrimitive !== "function") {
    return undefined;
  }

  const resolvedValue = symbolToPrimitive.call(value, "default");
  return isPrimitive(resolvedValue) ? resolvedValue : undefined;
}

function getObjectKeysByPriority(value: Record<string, unknown>) {
  const allKeys = Object.keys(value);
  const prioritizedKeys = WRAPPER_VALUE_KEYS.filter((key) => key in value);
  const otherKeys = allKeys.filter(
    (key) => !prioritizedKeys.includes(key as never)
  );

  return [...prioritizedKeys, ...otherKeys];
}

function isWrapperObject(value: Record<string, unknown>, key: string) {
  const otherKeys = Object.keys(value).filter((currentKey) => currentKey !== key);

  return otherKeys.every((currentKey) => isMetadataKey(currentKey));
}

function tryUnwrapKnownWrapper(value: Record<string, unknown>): unknown {
  for (const key of getObjectKeysByPriority(value)) {
    const candidate = value?.[key];
    if (candidate !== undefined && isWrapperObject(value, key)) {
      return candidate;
    }
  }

  return value;
}

function tryUnwrapSingleMeaningfulKey(value: Record<string, unknown>): unknown {
  const meaningfulKeys = Object.keys(value).filter((key) => !isMetadataKey(key));

  if (meaningfulKeys.length === 1) {
    return value?.[meaningfulKeys[0]];
  }

  return value;
}

function tryUnwrapSmallCellObject(value: Record<string, unknown>): unknown {
  const entries = Object.entries(value);

  if (entries.length === 0 || entries.length > 4) {
    return value;
  }

  const primitiveCandidates = entries.filter(([, entryValue]) =>
    isPrimitive(entryValue)
  );
  const objectCandidates = entries.filter(([, entryValue]) =>
    entryValue !== null && typeof entryValue === "object"
  );

  if (primitiveCandidates.length === 1 && objectCandidates.length === 0) {
    return primitiveCandidates[0]?.[1];
  }

  return value;
}

function normalizeObjectEntries(
  value: Record<string, unknown>,
  seen: WeakSet<object>
): Record<string, unknown> {
  const normalizedObject: Record<string, unknown> = {};

  for (const [key, entryValue] of Object.entries(value)) {
    normalizedObject[key] = normalizeDatabaseValue(entryValue, seen);
  }

  return normalizedObject;
}

export function normalizeDatabaseValue(
  value: unknown,
  seen: WeakSet<object> = new WeakSet()
): unknown {
  if (value === undefined) {
    return null;
  }

  if (isPrimitive(value)) {
    return value;
  }

  if (typeof value === "bigint") {
    return value.toString();
  }

  if (value instanceof Date) {
    return value.toISOString();
  }

  if (Array.isArray(value)) {
    return value.map((item) => normalizeDatabaseValue(item, seen));
  }

  if (typeof value === "object") {
    if (seen.has(value)) {
      return null;
    }

    seen.add(value);

    const primitiveFromSymbol = getPrimitiveFromSymbol(value);
    if (primitiveFromSymbol !== undefined) {
      return primitiveFromSymbol;
    }

    const primitiveFromValueOf = getPrimitiveFromValueOf(value);
    if (primitiveFromValueOf !== undefined) {
      return primitiveFromValueOf;
    }

    if (typeof (value as { toJSON?: () => unknown })?.toJSON === "function") {
      const jsonValue = (value as { toJSON: () => unknown }).toJSON();
      if (jsonValue !== value) {
        return normalizeDatabaseValue(jsonValue, seen);
      }
    }

    const plainValue = isPlainObject(value)
      ? value
      : Object.fromEntries(Object.entries(value as Record<string, unknown>));

    const knownWrapperValue = tryUnwrapKnownWrapper(plainValue);
    if (knownWrapperValue !== plainValue) {
      return normalizeDatabaseValue(knownWrapperValue, seen);
    }

    const singleMeaningfulValue = tryUnwrapSingleMeaningfulKey(plainValue);
    if (singleMeaningfulValue !== plainValue) {
      return normalizeDatabaseValue(singleMeaningfulValue, seen);
    }

    const smallCellValue = tryUnwrapSmallCellObject(plainValue);
    if (smallCellValue !== plainValue) {
      return normalizeDatabaseValue(smallCellValue, seen);
    }

    return normalizeObjectEntries(plainValue, seen);
  }

  return String(value) as Primitive;
}

export function normalizeDatabaseRows<T>(rows: T): T {
  return normalizeDatabaseValue(rows) as T;
}
