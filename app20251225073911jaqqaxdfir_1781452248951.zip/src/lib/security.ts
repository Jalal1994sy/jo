
import CrudOperations from "@/lib/crud-operations";
import { generateAdminUserToken } from "@/lib/auth";

type RateLimitEntry = {
  count: number;
  resetAt: number;
};

type SecurityEventParams = {
  userId?: number | null;
  companyId?: number | null;
  eventType: string;
  severity?: "info" | "warning" | "critical";
  resourceType?: string;
  resourceId?: string;
  requestId?: string;
  eventDetails?: Record<string, any>;
  ipAddress?: string | null;
  userAgent?: string | null;
};

const rateLimitStore = new Map<string, RateLimitEntry>();

function now() {
  return Date.now();
}

function cleanupRateLimitStore(currentTime: number) {
  for (const [key, value] of rateLimitStore.entries()) {
    if (value.resetAt <= currentTime) {
      rateLimitStore.delete(key);
    }
  }
}

export function createRequestId() {
  return `req_${now()}_${Math.random().toString(36).slice(2, 10)}`;
}

export function getClientIp(request: Request) {
  return (
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    request.headers.get("x-real-ip") ||
    request.headers.get("cf-connecting-ip") ||
    request.headers.get("x-client-ip") ||
    "unknown"
  );
}

export function assertSameOrigin(request: Request) {
  const method = request.method.toUpperCase();

  if (["GET", "HEAD", "OPTIONS"].includes(method)) {
    return;
  }

  const origin = request.headers.get("origin");
  const host = request.headers.get("host");

  if (!origin || !host) {
    throw new Error("Invalid request origin");
  }

  const originUrl = new URL(origin);
  if (originUrl.host !== host) {
    throw new Error("Cross-site request blocked");
  }
}

export function assertRateLimit(params: {
  key: string;
  limit: number;
  windowMs: number;
}) {
  const currentTime = now();
  cleanupRateLimitStore(currentTime);

  const existing = rateLimitStore.get(params.key);

  if (!existing || existing.resetAt <= currentTime) {
    rateLimitStore.set(params.key, {
      count: 1,
      resetAt: currentTime + params.windowMs,
    });
    return;
  }

  if (existing.count >= params.limit) {
    const secondsLeft = Math.max(1, Math.ceil((existing.resetAt - currentTime) / 1000));
    const error = new Error(`Rate limit exceeded. Retry in ${secondsLeft} seconds`);
    (error as any).status = 429;
    (error as any).code = "RATE_LIMITED";
    throw error;
  }

  existing.count += 1;
  rateLimitStore.set(params.key, existing);
}

export function isAuthRoute(pathname: string) {
  return pathname.startsWith("/next_api/auth/");
}

export async function logSecurityEvent(params: SecurityEventParams) {
  try {
    const adminToken = await generateAdminUserToken();
    const auditCrud = new CrudOperations("security_audit_logs", adminToken);

    await auditCrud.create({
      user_id: params.userId || null,
      company_id: params.companyId || null,
      event_type: params.eventType,
      severity: params.severity || "info",
      resource_type: params.resourceType || null,
      resource_id: params.resourceId || null,
      ip_address: params.ipAddress || null,
      user_agent: params.userAgent || null,
      request_id: params.requestId || null,
      event_details: params.eventDetails || {},
      occurred_at: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Failed to write security audit log:", error);
  }
}

export function assertPositiveInteger(value: string | number | null | undefined, fieldName: string) {
  const parsed = typeof value === "number" ? value : parseInt(String(value || ""), 10);

  if (!Number.isInteger(parsed) || parsed <= 0) {
    const error = new Error(`${fieldName} must be a positive integer`);
    (error as any).status = 400;
    throw error;
  }

  return parsed;
}

export function sanitizeText(value: string | null | undefined, maxLength: number) {
  if (!value) {
    return "";
  }

  return value.trim().slice(0, maxLength);
}
