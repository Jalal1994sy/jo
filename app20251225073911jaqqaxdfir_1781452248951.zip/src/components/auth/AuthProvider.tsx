
'use client';

import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { User } from '@/types/auth';
import { api } from '@/lib/api-client';
import { useRouter, usePathname } from 'next/navigation';
import type { AppLanguage } from '@/contexts/LanguageContext';

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  googleLogin: (access_token: string) => Promise<void>;
  register: (email: string, password: string, passcode: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

interface AuthProviderProps {
  children: React.ReactNode;
}

const VALID_LANGUAGES: AppLanguage[] = ['nl', 'fr', 'ar'];

function isValidLanguage(value: string | null | undefined): value is AppLanguage {
  return VALID_LANGUAGES.includes(value as AppLanguage);
}

// Routes where AuthProvider should NOT auto-redirect after fetching the user
const NO_REDIRECT_PREFIXES = [
  '/login',
  '/driver-login',
  '/sign-contract',
  '/invoice',
  '/faq',
  '/features',
];

function shouldSkipRedirect(pathname: string | null): boolean {
  if (!pathname) return true;
  if (pathname === '/') return false;
  return NO_REDIRECT_PREFIXES.some((prefix) => pathname.startsWith(prefix));
}

// Attempt to silently refresh the session using the refresh-token cookie
async function attemptSilentRefresh(): Promise<boolean> {
  try {
    const response = await fetch('/next_api/auth/refresh', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });
    if (!response.ok) return false;
    const result = await response.json();
    return result.success === true;
  } catch {
    return false;
  }
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const router = useRouter();
  const pathname = usePathname();

  const login = async (email: string, password: string) => {
    try {
      await api.post('/auth/login', { email, password });
      await refreshUser();
    } catch (error) {
      throw error;
    }
  };

  const register = async (email: string, password: string, passcode: string) => {
    try {
      await api.post('/auth/register', { email, password, passcode });
    } catch (error) {
      throw error;
    }
  };

  const logout = async () => {
    try {
      await api.post('/auth/logout');
      setUser(null);
      router.push('/login');
    } catch (error) {
      setUser(null);
      router.push('/login');
    }
  };

  const refreshUser = useCallback(async () => {
    try {
      const userData = await api.get('/auth/user');
      setUser(userData);

      // Only auto-redirect from auth/landing pages, not from in-app pages.
      const onAuthEntryPage =
        pathname === '/' ||
        pathname === '/login' ||
        pathname === '/driver-login';

      if (!onAuthEntryPage) {
        return;
      }

      if (userData?.userType === 'distributor') {
        router.push('/distributor/dashboard');
      } else if (userData?.userType === 'driver' && !userData?.isAdmin) {
        router.push('/driver/taximeter');
      } else if (
        userData?.userType === 'manager' ||
        userData?.userType === 'company' ||
        userData?.userType === 'owner'
      ) {
        router.push('/company/dashboard');
      } else {
        router.push('/dashboard');
      }
    } catch (error: any) {
      // If the access token is expired, try to silently refresh using the refresh token
      // This keeps the driver logged in even after closing the browser
      if (
        error?.errorCode === 'TOKEN_EXPIRED' ||
        error?.status === 401
      ) {
        const refreshed = await attemptSilentRefresh();
        if (refreshed) {
          // Retry fetching user after successful refresh
          try {
            const userData = await api.get('/auth/user');
            setUser(userData);
          } catch {
            setUser(null);
          }
        } else {
          // Refresh token also expired — clear user but do NOT redirect
          // The user will be redirected naturally when they try to access a protected page
          setUser(null);
        }
      } else {
        setUser(null);
      }
    } finally {
      setIsLoading(false);
    }
  }, [router, pathname]);

  const googleLogin = async (access_token: string) => {
    try {
      await api.post('/auth/google-login', {
        access_token,
        callback_url: window.location.origin,
      });
      await refreshUser();
    } catch (error) {
      console.error('Google login failed:', error);
      throw error;
    }
  };

  useEffect(() => {
    refreshUser();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900 dark:border-white"></div>
      </div>
    );
  }

  const value = {
    user,
    isLoading,
    login,
    googleLogin,
    register,
    logout,
    refreshUser,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}
