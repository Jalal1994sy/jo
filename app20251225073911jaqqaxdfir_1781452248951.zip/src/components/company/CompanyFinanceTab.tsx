
"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Banknote, Car, CreditCard, Euro, TrendingDown, TrendingUp } from "lucide-react";

interface FinanceData {
  period: string;
  start_date: string;
  end_date: string;
  totals: {
    revenue: number;
    subscriptions: number;
    expenses: number;
    profits: number;
    trips: number;
    invoices: number;
  };
  expenses_by_status: Record<string, number>;
  revenue_by_payment_method: Record<string, number>;
  latest_expenses: any[];
  latest_trips: any[];
}

interface CompanyFinanceTabProps {
  finance: FinanceData;
}

function StatCard({
  icon: Icon,
  label,
  value,
  className,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
  className?: string;
}) {
  return (
    <Card className="border border-border/50">
      <CardContent className="p-4 flex items-center gap-3">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${className || "bg-primary/10"}`}>
          <Icon className="w-5 h-5" />
        </div>
        <div>
          <p className="text-xs text-muted-foreground">{label}</p>
          <p className="text-xl font-bold">{value}</p>
        </div>
      </CardContent>
    </Card>
  );
}

export default function CompanyFinanceTab({ finance }: CompanyFinanceTabProps) {
  const paymentItems = Object.entries(finance?.revenue_by_payment_method || {});
  const expenseStatusItems = Object.entries(finance?.expenses_by_status || {});

  return (
    <div className="space-y-4">
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
        <StatCard
          icon={TrendingUp}
          label="Revenue"
          value={`€${finance?.totals?.revenue?.toFixed(2) || "0.00"}`}
          className="bg-green-500/10 text-green-600"
        />
        <StatCard
          icon={CreditCard}
          label="Subscriptions"
          value={`€${finance?.totals?.subscriptions?.toFixed(2) || "0.00"}`}
          className="bg-blue-500/10 text-blue-600"
        />
        <StatCard
          icon={TrendingDown}
          label="Expenses"
          value={`€${finance?.totals?.expenses?.toFixed(2) || "0.00"}`}
          className="bg-red-500/10 text-red-600"
        />
        <StatCard
          icon={Euro}
          label="Profits"
          value={`€${finance?.totals?.profits?.toFixed(2) || "0.00"}`}
          className="bg-violet-500/10 text-violet-600"
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardContent className="p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">Business Totals</h3>
              <Badge variant="outline">{finance?.period || "monthly"}</Badge>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="rounded-xl border p-3">
                <p className="text-xs text-muted-foreground">Trips</p>
                <p className="text-2xl font-bold">{finance?.totals?.trips || 0}</p>
              </div>
              <div className="rounded-xl border p-3">
                <p className="text-xs text-muted-foreground">Invoices</p>
                <p className="text-2xl font-bold">{finance?.totals?.invoices || 0}</p>
              </div>
              <div className="rounded-xl border p-3 sm:col-span-2">
                <p className="text-xs text-muted-foreground">Period</p>
                <p className="text-sm font-medium">
                  {new Date(finance?.start_date || Date.now()).toLocaleDateString()} -{" "}
                  {new Date(finance?.end_date || Date.now()).toLocaleDateString()}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5 space-y-3">
            <h3 className="font-semibold">Revenue by Payment Method</h3>
            {paymentItems.length === 0 ? (
              <p className="text-sm text-muted-foreground">No payment data available.</p>
            ) : (
              paymentItems.map(([key, value]) => (
                <div key={key} className="flex items-center justify-between rounded-xl border p-3">
                  <div className="flex items-center gap-2">
                    <Banknote className="w-4 h-4 text-primary" />
                    <span className="text-sm capitalize">{key.replaceAll("_", " ")}</span>
                  </div>
                  <span className="text-sm font-semibold">€{Number(value).toFixed(2)}</span>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardContent className="p-5 space-y-3">
            <h3 className="font-semibold">Expense Status Breakdown</h3>
            {expenseStatusItems.length === 0 ? (
              <p className="text-sm text-muted-foreground">No expense data available.</p>
            ) : (
              expenseStatusItems.map(([key, value]) => (
                <div key={key} className="flex items-center justify-between rounded-xl border p-3">
                  <span className="text-sm capitalize">{key.replaceAll("_", " ")}</span>
                  <span className="text-sm font-semibold">€{Number(value).toFixed(2)}</span>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5 space-y-3">
            <h3 className="font-semibold">Latest Trips</h3>
            {(finance?.latest_trips || []).length === 0 ? (
              <p className="text-sm text-muted-foreground">No trips available.</p>
            ) : (
              (finance?.latest_trips || []).map((trip: any) => (
                <div key={trip?.id} className="flex items-center justify-between rounded-xl border p-3">
                  <div className="flex items-center gap-2 min-w-0">
                    <Car className="w-4 h-4 text-primary" />
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{trip?.start_address || "Trip"}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(trip?.start_time || Date.now()).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <span className="text-sm font-semibold">€{Number(trip?.price || 0).toFixed(2)}</span>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
