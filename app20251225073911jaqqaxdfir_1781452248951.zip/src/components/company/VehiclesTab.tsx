
"use client";

import { useEffect, useState } from "react";
import { upload } from "@zoerai/integration";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { api } from "@/lib/api-client";
import { toast } from "sonner";
import {
  Car,
  Eye,
  FileText,
  Loader2,
  Paperclip,
  Pencil,
  Plus,
  Trash2,
  Upload,
} from "lucide-react";

interface Vehicle {
  id: number;
  brand: string;
  model: string;
  plate_number: string;
  vin?: string;
  status: string;
}

interface VehicleDocument {
  id: number;
  vehicle_id: number;
  document_type: string;
  file_name: string;
  file_url: string;
  approval_status: string;
  expiry_date?: string | null;
  locked_after_approval: boolean;
  issued_date?: string | null;
  document_number?: string | null;
}

interface VehiclesTabProps {
  vehicles: Vehicle[];
  onRefresh: () => void;
}

const emptyForm = { brand: "", model: "", plate_number: "", vin: "" };
const DOCUMENT_TYPES = [
  { value: "controle_technique", label: "Controle Technique" },
  { value: "assurance", label: "Assurance" },
  { value: "certificat_immatriculation", label: "Certificat d'immatriculation" },
  { value: "vignette_taxi", label: "Vignette Taxi" },
];

export default function VehiclesTab({ vehicles, onRefresh }: VehiclesTabProps) {
  const [showDialog, setShowDialog] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [loading, setLoading] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);

  const [docsOpen, setDocsOpen] = useState(false);
  const [docsLoading, setDocsLoading] = useState(false);
  const [docsSaving, setDocsSaving] = useState(false);
  const [docsUploading, setDocsUploading] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
  const [documents, setDocuments] = useState<VehicleDocument[]>([]);
  const [docForm, setDocForm] = useState({
    document_type: "controle_technique",
    document_number: "",
    issued_date: "",
    expiry_date: "",
    notes: "",
  });
  const [uploadedPdf, setUploadedPdf] = useState<{
    file_name: string;
    file_url: string;
    file_key?: string;
    file_size_bytes?: number;
  } | null>(null);

  const openAdd = () => {
    setEditingVehicle(null);
    setForm(emptyForm);
    setShowDialog(true);
  };

  const openEdit = (v: Vehicle) => {
    setEditingVehicle(v);
    setForm({ brand: v.brand, model: v.model, plate_number: v.plate_number, vin: v.vin || "" });
    setShowDialog(true);
  };

  const fetchVehicleDocuments = async (vehicleId: number) => {
    setDocsLoading(true);
    try {
      const data = await api.get<VehicleDocument[]>(`/company-portal/vehicle-documents?vehicle_id=${vehicleId}`);
      setDocuments(data || []);
    } catch (error: any) {
      toast.error(error?.message || "Failed to load vehicle documents");
    } finally {
      setDocsLoading(false);
    }
  };

  const openDocuments = async (vehicle: Vehicle) => {
    setSelectedVehicle(vehicle);
    setUploadedPdf(null);
    setDocForm({
      document_type: "controle_technique",
      document_number: "",
      issued_date: "",
      expiry_date: "",
      notes: "",
    });
    setDocsOpen(true);
    await fetchVehicleDocuments(vehicle.id);
  };

  useEffect(() => {
    if (!docsOpen) {
      setSelectedVehicle(null);
      setDocuments([]);
    }
  }, [docsOpen]);

  const handleSave = async () => {
    if (!form.brand || !form.model || !form.plate_number) {
      toast.error("Brand, model and plate number are required");
      return;
    }

    setLoading(true);

    try {
      if (editingVehicle) {
        await api.put(`/company-portal/vehicles?id=${editingVehicle.id}`, form);
        toast.success("Vehicle updated successfully");
      } else {
        await api.post("/company-portal/vehicles", form);
        toast.success("Vehicle added successfully");
      }

      setShowDialog(false);
      onRefresh();
    } catch (err: any) {
      toast.error(err.message || "Operation failed");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    setDeletingId(id);

    try {
      await api.delete(`/company-portal/vehicles?id=${id}`);
      toast.success("Vehicle removed");
      onRefresh();
    } catch (err: any) {
      toast.error(err.message || "Failed to delete vehicle");
    } finally {
      setDeletingId(null);
    }
  };

  const handlePdfUpload = async (file: File) => {
    setDocsUploading(true);

    try {
      const result = await upload.uploadWithPresignedUrl(file, {
        fileName: file.name,
        maxSize: 5 * 1024 * 1024,
        allowedExtensions: [".pdf"],
      });

      if (!result.success || !result.url) {
        toast.error(result.error || "Upload failed");
        return;
      }

      setUploadedPdf({
        file_name: file.name,
        file_url: result.url,
        file_key: result.fileKey,
        file_size_bytes: file.size,
      });

      toast.success("PDF uploaded");
    } catch (error: any) {
      toast.error(error?.message || "Upload failed");
    } finally {
      setDocsUploading(false);
    }
  };

  const handleCreateDocument = async () => {
    if (!selectedVehicle) {
      return;
    }

    if (!uploadedPdf) {
      toast.error("Please upload a PDF first");
      return;
    }

    setDocsSaving(true);

    try {
      await api.post("/company-portal/vehicle-documents", {
        vehicle_id: selectedVehicle.id,
        document_type: docForm.document_type,
        document_number: docForm.document_number || null,
        issued_date: docForm.issued_date || null,
        expiry_date: docForm.expiry_date || null,
        notes: docForm.notes || null,
        file_name: uploadedPdf.file_name,
        file_url: uploadedPdf.file_url,
        file_key: uploadedPdf.file_key,
        file_size_bytes: uploadedPdf.file_size_bytes,
      });

      toast.success("Vehicle document saved");
      setUploadedPdf(null);
      setDocForm({
        document_type: "controle_technique",
        document_number: "",
        issued_date: "",
        expiry_date: "",
        notes: "",
      });
      await fetchVehicleDocuments(selectedVehicle.id);
      onRefresh();
    } catch (error: any) {
      toast.error(error?.message || "Failed to save document");
    } finally {
      setDocsSaving(false);
    }
  };

  const handleDeleteDocument = async (documentId: number) => {
    try {
      await api.delete(`/company-portal/vehicle-documents?id=${documentId}`);
      toast.success("Document deleted");
      if (selectedVehicle) {
        await fetchVehicleDocuments(selectedVehicle.id);
      }
    } catch (error: any) {
      toast.error(error?.message || "Failed to delete document");
    }
  };

  const statusColor = (s: string) =>
    s === "active"
      ? "bg-green-500/10 text-green-600 border-green-500/20"
      : s === "maintenance"
        ? "bg-yellow-500/10 text-yellow-600 border-yellow-500/20"
        : "bg-red-500/10 text-red-600 border-red-500/20";

  const approvalColor = (status: string) =>
    status === "approved"
      ? "bg-green-500/10 text-green-600 border-green-500/20"
      : status === "rejected"
        ? "bg-red-500/10 text-red-600 border-red-500/20"
        : "bg-yellow-500/10 text-yellow-600 border-yellow-500/20";

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <p className="text-sm text-muted-foreground">{vehicles.length} vehicle(s) registered</p>
        <Button onClick={openAdd} size="sm" className="gap-2">
          <Plus className="w-4 h-4" /> Add Vehicle
        </Button>
      </div>

      {vehicles.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <Car className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p>No vehicles registered yet</p>
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {vehicles.map((v) => (
            <Card key={v.id} className="border border-border/50">
              <CardContent className="p-4">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                      <Car className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-semibold">
                        {v.brand} {v.model}
                      </p>
                      <p className="text-sm text-muted-foreground font-mono">{v.plate_number}</p>
                    </div>
                  </div>
                  <Badge variant="outline" className={`text-xs ${statusColor(v.status)}`}>
                    {v.status}
                  </Badge>
                </div>

                <div className="mt-4 flex items-center justify-end gap-2">
                  <Button variant="outline" size="sm" onClick={() => openDocuments(v)}>
                    <FileText className="w-4 h-4 mr-1" />
                    Documents
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(v)}>
                    <Pencil className="w-3.5 h-3.5" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-destructive hover:text-destructive"
                    onClick={() => handleDelete(v.id)}
                    disabled={deletingId === v.id}
                  >
                    {deletingId === v.id ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Trash2 className="w-3.5 h-3.5" />
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingVehicle ? "Edit Vehicle" : "Add New Vehicle"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Brand *</Label>
                <Input placeholder="Toyota" value={form.brand} onChange={(e) => setForm((f) => ({ ...f, brand: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label>Model *</Label>
                <Input placeholder="Camry" value={form.model} onChange={(e) => setForm((f) => ({ ...f, model: e.target.value }))} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Plate Number *</Label>
              <Input placeholder="1-ABC-123" value={form.plate_number} onChange={(e) => setForm((f) => ({ ...f, plate_number: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label>VIN (optional)</Label>
              <Input placeholder="Vehicle identification number" value={form.vin} onChange={(e) => setForm((f) => ({ ...f, vin: e.target.value }))} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={loading}>
              {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              {editingVehicle ? "Save Changes" : "Add Vehicle"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={docsOpen} onOpenChange={setDocsOpen}>
        <DialogContent className="sm:max-w-3xl">
          <DialogHeader>
            <DialogTitle>
              Vehicle Documents{selectedVehicle ? ` - ${selectedVehicle.brand} ${selectedVehicle.model}` : ""}
            </DialogTitle>
          </DialogHeader>

          <div className="grid gap-6 lg:grid-cols-[320px_1fr]">
            <div className="space-y-4 border rounded-xl p-4">
              <div className="space-y-1.5">
                <Label>Document Type</Label>
                <select
                  className="w-full h-10 rounded-md border bg-background px-3 text-sm"
                  value={docForm.document_type}
                  onChange={(e) => setDocForm((prev) => ({ ...prev, document_type: e.target.value }))}
                >
                  {DOCUMENT_TYPES.map((item) => (
                    <option key={item.value} value={item.value}>
                      {item.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <Label>Document Number</Label>
                <Input
                  value={docForm.document_number}
                  onChange={(e) => setDocForm((prev) => ({ ...prev, document_number: e.target.value }))}
                  placeholder="Optional"
                />
              </div>

              <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-1">
                <div className="space-y-1.5">
                  <Label>Issued Date</Label>
                  <Input
                    type="date"
                    value={docForm.issued_date}
                    onChange={(e) => setDocForm((prev) => ({ ...prev, issued_date: e.target.value }))}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>Expiry Date</Label>
                  <Input
                    type="date"
                    value={docForm.expiry_date}
                    onChange={(e) => setDocForm((prev) => ({ ...prev, expiry_date: e.target.value }))}
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <Label>Notes</Label>
                <Input
                  value={docForm.notes}
                  onChange={(e) => setDocForm((prev) => ({ ...prev, notes: e.target.value }))}
                  placeholder="Optional"
                />
              </div>

              <div className="space-y-2">
                <Label>PDF File</Label>
                <label className="flex h-10 cursor-pointer items-center justify-center rounded-md border border-dashed text-sm">
                  <input
                    type="file"
                    accept="application/pdf,.pdf"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        handlePdfUpload(file);
                      }
                      e.currentTarget.value = "";
                    }}
                  />
                  {docsUploading ? (
                    <span className="flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Uploading...
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      <Upload className="w-4 h-4" />
                      Upload PDF
                    </span>
                  )}
                </label>

                {uploadedPdf ? (
                  <div className="flex items-center gap-2 rounded-xl border p-2 text-sm">
                    <Paperclip className="w-4 h-4 text-primary" />
                    <span className="truncate">{uploadedPdf.file_name}</span>
                  </div>
                ) : null}
              </div>

              <Button className="w-full" onClick={handleCreateDocument} disabled={docsSaving || docsUploading}>
                {docsSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                Save Document
              </Button>
            </div>

            <div className="space-y-3">
              {docsLoading ? (
                <Card>
                  <CardContent className="p-6 text-sm text-muted-foreground">Loading documents...</CardContent>
                </Card>
              ) : documents.length === 0 ? (
                <Card>
                  <CardContent className="p-6 text-sm text-muted-foreground">No documents uploaded yet.</CardContent>
                </Card>
              ) : (
                documents.map((doc) => (
                  <Card key={doc.id}>
                    <CardContent className="p-4 space-y-3">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <p className="font-semibold">
                            {DOCUMENT_TYPES.find((item) => item.value === doc.document_type)?.label || doc.document_type}
                          </p>
                          <p className="text-sm text-muted-foreground">{doc.file_name}</p>
                        </div>
                        <div className="flex flex-wrap items-center gap-2">
                          <Badge variant="outline" className={approvalColor(doc.approval_status)}>
                            {doc.approval_status}
                          </Badge>
                          {doc.locked_after_approval ? (
                            <Badge variant="secondary">locked</Badge>
                          ) : null}
                        </div>
                      </div>

                      <div className="grid gap-2 sm:grid-cols-2 text-sm text-muted-foreground">
                        <p>Issued: {doc.issued_date || "-"}</p>
                        <p>Expiry: {doc.expiry_date || "-"}</p>
                        <p>Number: {doc.document_number || "-"}</p>
                      </div>

                      <div className="flex items-center justify-end gap-2">
                        <a href={doc.file_url} target="_blank" rel="noreferrer">
                          <Button variant="outline" size="sm">
                            <Eye className="w-4 h-4 mr-1" />
                            View PDF
                          </Button>
                        </a>
                        {!doc.locked_after_approval && doc.approval_status !== "approved" ? (
                          <Button variant="destructive" size="sm" onClick={() => handleDeleteDocument(doc.id)}>
                            <Trash2 className="w-4 h-4 mr-1" />
                            Delete
                          </Button>
                        ) : null}
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
