
"use client";

import { useEffect, useMemo, useState } from "react";
import { upload } from "@zoerai/integration";
import { api } from "@/lib/api-client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Paperclip, Plus, Receipt, Trash2 } from "lucide-react";

interface ExpenseCategory {
  id: number;
  code: string;
  name: string;
}

interface ExpenseAttachment {
  id?: number;
  file_name: string;
  file_url: string;
  file_key?: string;
  file_size_bytes?: number;
  document_type?: string;
}

interface ExpenseItem {
  id: number;
  type: string;
  amount: number;
  expense_date: string;
  description?: string;
  expense_status?: string;
  category_id?: number | null;
  attachments?: ExpenseAttachment[];
  category?: ExpenseCategory | null;
}

interface CompanyExpensesTabProps {
  companyId: number;
}

const EMPTY_FORM = {
  type: "",
  amount: "",
  expense_date: "",
  description: "",
  category_id: "",
  expense_status: "draft",
};

export default function CompanyExpensesTab({ companyId }: CompanyExpensesTabProps) {
  const [expenses, setExpenses] = useState<ExpenseItem[]>([]);
  const [categories, setCategories] = useState<ExpenseCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [open, setOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<ExpenseItem | null>(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [attachments, setAttachments] = useState<ExpenseAttachment[]>([]);
  const [uploading, setUploading] = useState(false);

  const totalExpenses = useMemo(
    () => expenses.reduce((sum, item) => sum + Number(item?.amount || 0), 0),
    [expenses]
  );

  const fetchData = async () => {
    setLoading(true);
    try {
      const [expenseData, categoryData] = await Promise.all([
        api.get<ExpenseItem[]>(`/expenses?company_id=${companyId}`),
        api.get<ExpenseCategory[]>("/company-portal/expense-categories"),
      ]);

      setExpenses(expenseData || []);
      setCategories(categoryData || []);
    } catch (error: any) {
      toast.error(error?.message || "Failed to load expenses");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [companyId]);

  const resetForm = () => {
    setEditingExpense(null);
    setForm(EMPTY_FORM);
    setAttachments([]);
  };

  const openCreate = () => {
    resetForm();
    setOpen(true);
  };

  const openEdit = (expense: ExpenseItem) => {
    setEditingExpense(expense);
    setForm({
      type: expense?.type || "",
      amount: String(expense?.amount || ""),
      expense_date: expense?.expense_date || "",
      description: expense?.description || "",
      category_id: expense?.category_id ? String(expense.category_id) : "",
      expense_status: expense?.expense_status || "draft",
    });
    setAttachments([]);
    setOpen(true);
  };

  const handleUpload = async (file: File) => {
    setUploading(true);
    try {
      const result = await upload.uploadWithPresignedUrl(file, {
        fileName: file.name,
        maxSize: 5 * 1024 * 1024,
        allowedExtensions: [".pdf"],
      });

      if (!result.success || !result.url) {
        toast.error(result.error || "Upload failed");
        return;
      }

      setAttachments((prev) => [
        ...prev,
        {
          file_name: file.name,
          file_url: result.url || "",
          file_key: result.fileKey,
          file_size_bytes: file.size,
          document_type: "receipt",
        },
      ]);

      toast.success("Attachment uploaded");
    } catch (error: any) {
      toast.error(error?.message || "Upload failed");
    } finally {
      setUploading(false);
    }
  };

  const handleSave = async () => {
    if (!form.type || !form.amount || !form.expense_date) {
      toast.error("Type, amount and date are required");
      return;
    }

    setSaving(true);

    const payload = {
      company_id: companyId,
      type: form.type,
      amount: Number(form.amount),
      expense_date: form.expense_date,
      description: form.description || null,
      category_id: form.category_id ? Number(form.category_id) : null,
      expense_status: form.expense_status,
      attachments,
    };

    try {
      if (editingExpense) {
        await api.put(`/expenses?id=${editingExpense.id}`, payload);
        toast.success("Expense updated");
      } else {
        await api.post("/expenses", payload);
        toast.success("Expense created");
      }

      setOpen(false);
      resetForm();
      fetchData();
    } catch (error: any) {
      toast.error(error?.message || "Failed to save expense");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (expenseId: number) => {
    try {
      await api.delete(`/expenses?id=${expenseId}`);
      toast.success("Expense deleted");
      fetchData();
    } catch (error: any) {
      toast.error(error?.message || "Failed to delete expense");
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-sm text-muted-foreground">Total expenses</p>
          <p className="text-2xl font-bold">€{totalExpenses.toFixed(2)}</p>
        </div>
        <Button onClick={openCreate} className="gap-2">
          <Plus className="w-4 h-4" />
          Add Expense
        </Button>
      </div>

      <div className="grid gap-3">
        {loading ? (
          <Card>
            <CardContent className="p-6 text-sm text-muted-foreground">Loading expenses...</CardContent>
          </Card>
        ) : expenses.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-sm text-muted-foreground">No expenses found.</CardContent>
          </Card>
        ) : (
          expenses.map((expense) => (
            <Card key={expense.id}>
              <CardContent className="p-4 space-y-3">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="font-semibold">{expense?.type}</p>
                    <p className="text-sm text-muted-foreground">
                      {expense?.category?.name || "Uncategorized"} • {expense?.expense_date}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">€{Number(expense?.amount || 0).toFixed(2)}</p>
                    <p className="text-xs text-muted-foreground capitalize">
                      {(expense?.expense_status || "draft").replaceAll("_", " ")}
                    </p>
                  </div>
                </div>

                {expense?.description ? (
                  <p className="text-sm text-muted-foreground">{expense.description}</p>
                ) : null}

                {(expense?.attachments || []).length > 0 ? (
                  <div className="space-y-2">
                    {(expense.attachments || []).map((file, index) => (
                      <a
                        key={`${expense.id}_${index}`}
                        href={file?.file_url}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center gap-2 rounded-xl border p-2 text-sm hover:bg-muted/40"
                      >
                        <Paperclip className="w-4 h-4 text-primary" />
                        <span className="truncate">{file?.file_name}</span>
                      </a>
                    ))}
                  </div>
                ) : null}

                <div className="flex items-center justify-end gap-2">
                  <Button variant="outline" size="sm" onClick={() => openEdit(expense)}>
                    Edit
                  </Button>
                  <Button variant="destructive" size="sm" onClick={() => handleDelete(expense.id)}>
                    <Trash2 className="w-4 h-4 mr-1" />
                    Delete
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingExpense ? "Edit Expense" : "Add Expense"}</DialogTitle>
          </DialogHeader>

          <div className="grid gap-4 py-2">
            <div className="grid gap-2 md:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Type</Label>
                <Input
                  value={form.type}
                  onChange={(e) => setForm((prev) => ({ ...prev, type: e.target.value }))}
                  placeholder="Fuel"
                />
              </div>
              <div className="space-y-1.5">
                <Label>Amount</Label>
                <Input
                  type="number"
                  min="0"
                  step="0.01"
                  value={form.amount}
                  onChange={(e) => setForm((prev) => ({ ...prev, amount: e.target.value }))}
                  placeholder="0.00"
                />
              </div>
            </div>

            <div className="grid gap-2 md:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Date</Label>
                <Input
                  type="date"
                  value={form.expense_date}
                  onChange={(e) => setForm((prev) => ({ ...prev, expense_date: e.target.value }))}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Category</Label>
                <select
                  className="w-full h-10 rounded-md border bg-background px-3 text-sm"
                  value={form.category_id}
                  onChange={(e) => setForm((prev) => ({ ...prev, category_id: e.target.value }))}
                >
                  <option value="">Select category</option>
                  {categories.map((item) => (
                    <option key={item.id} value={String(item.id)}>
                      {item.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>Status</Label>
              <select
                className="w-full h-10 rounded-md border bg-background px-3 text-sm"
                value={form.expense_status}
                onChange={(e) => setForm((prev) => ({ ...prev, expense_status: e.target.value }))}
              >
                <option value="draft">draft</option>
                <option value="submitted">submitted</option>
                <option value="approved">approved</option>
                <option value="paid">paid</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <Label>Description</Label>
              <Input
                value={form.description}
                onChange={(e) => setForm((prev) => ({ ...prev, description: e.target.value }))}
                placeholder="Optional note"
              />
            </div>

            <div className="space-y-2">
              <Label>PDF Attachments</Label>
              <label className="flex h-10 cursor-pointer items-center justify-center rounded-md border border-dashed text-sm">
                <input
                  type="file"
                  accept="application/pdf,.pdf"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      handleUpload(file);
                    }
                    e.currentTarget.value = "";
                  }}
                />
                {uploading ? (
                  <span className="flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Uploading...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    <Receipt className="w-4 h-4" />
                    Upload PDF
                  </span>
                )}
              </label>

              {attachments.length > 0 ? (
                <div className="space-y-2">
                  {attachments.map((file, index) => (
                    <div key={`${file.file_name}_${index}`} className="flex items-center justify-between rounded-xl border p-2 text-sm">
                      <span className="truncate">{file.file_name}</span>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => setAttachments((prev) => prev.filter((_, itemIndex) => itemIndex !== index))}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : null}
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={saving || uploading}>
              {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
              {editingExpense ? "Save Changes" : "Create Expense"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
