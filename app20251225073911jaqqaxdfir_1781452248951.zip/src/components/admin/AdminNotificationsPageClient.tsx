
"use client";

import AdminNotificationsPage from "@/app/admin/notifications/page-impl";

export default function AdminNotificationsPageClient() {
  return <AdminNotificationsPage />;
}
