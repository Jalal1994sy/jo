
"use client";

import AdminMessagesPage from "@/app/admin/messages/page-impl";

export default function AdminMessagesPageClient() {
  return <AdminMessagesPage />;
}
