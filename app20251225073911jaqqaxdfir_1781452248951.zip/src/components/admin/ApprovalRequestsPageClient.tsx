
"use client";

import ApprovalRequestsPage from "@/app/admin/approval-requests/page-impl";

export default function ApprovalRequestsPageClient() {
  return <ApprovalRequestsPage />;
}
