
"use client";

import CompaniesPage from "@/app/admin/companies/page-impl";

export default function CompaniesPageClient() {
  return <CompaniesPage />;
}
