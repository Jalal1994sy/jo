
"use client";

import ChironSyncPage from "@/app/admin/chiron-sync/page-impl";

export default function ChironSyncPageClient() {
  return <ChironSyncPage />;
}
