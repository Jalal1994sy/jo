"use client";

import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Cookie, ChevronDown, ChevronUp, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { api } from "@/lib/api-client";
import { useAuth } from "@/components/auth/AuthProvider";
import { useLanguage } from "@/contexts/LanguageContext";
import Link from "next/link";

interface CookieCategory {
  id: number;
  code: string;
  name: string;
  description?: string;
  is_required: boolean;
  display_order: number;
}

const STORAGE_KEY = "gdpr_cookie_consent";
const CONSENT_VERSION = "1.0";

const T = {
  nl: {
    title: "Wij gebruiken cookies",
    desc: "We gebruiken cookies om uw ervaring te verbeteren. U kunt uw voorkeuren instellen.",
    acceptAll: "Alles accepteren",
    reject: "Weigeren",
    customize: "Aanpassen",
    save: "Opslaan",
    required: "Verplicht",
    privacy: "Privacybeleid",
  },
  fr: {
    title: "Nous utilisons des cookies",
    desc: "Nous utilisons des cookies pour améliorer votre expérience. Vous pouvez gérer vos préférences.",
    acceptAll: "Tout accepter",
    reject: "Refuser",
    customize: "Personnaliser",
    save: "Enregistrer",
    required: "Requis",
    privacy: "Politique de confidentialité",
  },
  ar: {
    title: "نستخدم ملفات تعريف الارتباط",
    desc: "نستخدم ملفات تعريف الارتباط لتحسين تجربتك. يمكنك إدارة تفضيلاتك.",
    acceptAll: "قبول الكل",
    reject: "رفض",
    customize: "تخصيص",
    save: "حفظ",
    required: "مطلوب",
    privacy: "سياسة الخصوصية",
  },
};

const DEFAULT_CATEGORIES: CookieCategory[] = [
  {
    id: 1,
    code: "essential",
    name: "Essential",
    description: "Required for site functionality.",
    is_required: true,
    display_order: 0,
  },
  {
    id: 2,
    code: "analytics",
    name: "Analytics",
    description: "Help us understand how you use the app.",
    is_required: false,
    display_order: 1,
  },
  {
    id: 3,
    code: "marketing",
    name: "Marketing",
    description: "Personalized content and offers.",
    is_required: false,
    display_order: 2,
  },
];

export default function CookieBanner() {
  const { user } = useAuth();
  const { language, isRtl } = useLanguage();
  const t = T[language] ?? T.fr;

  const [show, setShow] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [categories, setCategories] = useState<CookieCategory[]>([]);
  const [choices, setChoices] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        if (parsed?.version === CONSENT_VERSION) {
          return;
        }
      } catch {}
    }

    const timer = setTimeout(() => setShow(true), 1800);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (!show) {
      return;
    }

    api.get<CookieCategory[]>("/gdpr/cookie-categories")
      .then((data) => {
        const categoriesData = data?.length ? data : DEFAULT_CATEGORIES;
        setCategories(categoriesData);

        const initialChoices: Record<string, boolean> = {};
        categoriesData.forEach((category) => {
          initialChoices[category.code] = category.is_required;
        });
        setChoices(initialChoices);
      })
      .catch(() => {
        setCategories(DEFAULT_CATEGORIES);

        const initialChoices: Record<string, boolean> = {};
        DEFAULT_CATEGORIES.forEach((category) => {
          initialChoices[category.code] = category.is_required;
        });
        setChoices(initialChoices);
      });
  }, [show]);

  const persist = useCallback(
    async (finalChoices: Record<string, boolean>) => {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({
          version: CONSENT_VERSION,
          timestamp: new Date().toISOString(),
          categories: finalChoices,
        })
      );

      if (user) {
        try {
          const payload = Object.entries(finalChoices).map(([key, granted]) => ({
            consent_scope: "cookie_category",
            consent_key: key,
            consent_version: CONSENT_VERSION,
            granted,
          }));

          await api.post("/gdpr/consents", { consents: payload });
        } catch {}
      }

      setShow(false);
    },
    [user]
  );

  const acceptAll = useCallback(() => {
    const allChoices: Record<string, boolean> = {};
    categories.forEach((category) => {
      allChoices[category.code] = true;
    });
    persist(allChoices);
  }, [categories, persist]);

  const rejectNonEssential = useCallback(() => {
    const minimalChoices: Record<string, boolean> = {};
    categories.forEach((category) => {
      minimalChoices[category.code] = category.is_required;
    });
    persist(minimalChoices);
  }, [categories, persist]);

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ y: 120, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 120, opacity: 0 }}
          transition={{ type: "spring", stiffness: 280, damping: 28 }}
          dir={isRtl ? "rtl" : "ltr"}
          className="fixed bottom-0 left-0 right-0 z-[99999] p-3 sm:p-4"
        >
          <div className="mx-auto max-w-2xl overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl dark:border-slate-700 dark:bg-slate-900">
            <div className="flex items-start gap-3 p-4">
              <div className="mt-0.5 flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-xl bg-amber-100 dark:bg-amber-900/30">
                <Cookie className="h-4 w-4 text-amber-600 dark:text-amber-400" />
              </div>

              <div className="min-w-0 flex-1">
                <p className="text-sm font-bold text-slate-900 dark:text-white">{t.title}</p>
                <p className="mt-0.5 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
                  {t.desc}
                </p>
              </div>
            </div>

            <AnimatePresence>
              {expanded && (
                <motion.div
                  initial={{ height: 0 }}
                  animate={{ height: "auto" }}
                  exit={{ height: 0 }}
                  className="overflow-hidden border-t border-slate-100 dark:border-slate-800"
                >
                  <div className="space-y-3 px-4 py-3">
                    {categories.map((category) => (
                      <div key={category.code} className="flex items-center justify-between gap-3">
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                              {category.name}
                            </span>
                            {category.is_required && (
                              <span className="rounded-full bg-blue-100 px-1.5 py-0.5 text-[10px] font-medium text-blue-600 dark:bg-blue-900/30 dark:text-blue-400">
                                {t.required}
                              </span>
                            )}
                          </div>

                          {category.description && (
                            <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
                              {category.description}
                            </p>
                          )}
                        </div>

                        <Switch
                          checked={choices[category.code] ?? false}
                          onCheckedChange={() => {
                            if (!category.is_required) {
                              setChoices((prev) => ({
                                ...prev,
                                [category.code]: !prev[category.code],
                              }));
                            }
                          }}
                          disabled={category.is_required}
                        />
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 bg-slate-50 px-4 py-3 dark:border-slate-800 dark:bg-slate-800/60">
              <div className="flex items-center gap-3">
                <Link
                  href="/privacy-policy"
                  className="flex items-center gap-1 text-xs text-slate-500 transition-colors hover:text-slate-700 dark:hover:text-slate-300"
                >
                  <Shield className="h-3 w-3" />
                  {t.privacy}
                </Link>

                <button
                  onClick={() => setExpanded((value) => !value)}
                  className="flex items-center gap-1 text-xs text-slate-500 transition-colors hover:text-slate-700 dark:hover:text-slate-300"
                >
                  {t.customize}
                  {expanded ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                </button>
              </div>

              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8 rounded-xl text-xs"
                  onClick={rejectNonEssential}
                >
                  {t.reject}
                </Button>

                {expanded ? (
                  <Button
                    size="sm"
                    className="h-8 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-600 text-xs"
                    onClick={() => persist(choices)}
                  >
                    {t.save}
                  </Button>
                ) : (
                  <Button
                    size="sm"
                    className="h-8 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-600 text-xs"
                    onClick={acceptAll}
                  >
                    {t.acceptAll}
                  </Button>
                )}
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
