"use client";

import { useEffect } from "react";
import { usePathname } from "next/navigation";
import SiteAIAgent from "@/components/ai/SiteAIAgent";

export default function GlobalClientEffects() {
  const pathname = usePathname();

  const isDriverPortal =
    pathname === "/driver-login" || (pathname?.startsWith("/driver/") ?? false);

  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker
        .register("/sw.js", { scope: "/" })
        .then((registration) => {
          console.log("SW registered:", registration.scope);

          registration.addEventListener("updatefound", () => {
            const newWorker = registration.installing;
            if (newWorker) {
              newWorker.addEventListener("statechange", () => {
                if (newWorker.state === "installed" && navigator.serviceWorker.controller) {
                  console.log("New SW available");
                }
              });
            }
          });
        })
        .catch((err) => console.warn("SW registration failed:", err));
    }

    let lastTouchEnd = 0;
    const preventDoubleTapZoom = (event: TouchEvent) => {
      const now = Date.now();
      if (now - lastTouchEnd <= 300) {
        event.preventDefault();
      }
      lastTouchEnd = now;
    };

    document.addEventListener("touchend", preventDoubleTapZoom, { passive: false });

    let startY = 0;
    const onTouchStart = (event: TouchEvent) => {
      startY = event.touches[0]?.clientY || 0;
    };

    const preventPullToRefresh = (event: TouchEvent) => {
      if (event.touches.length !== 1) {
        return;
      }

      const touch = event.touches[0];
      if (!touch) {
        return;
      }

      const deltaY = touch.clientY - startY;
      if (deltaY > 0 && window.scrollY === 0) {
        event.preventDefault();
      }
    };

    document.addEventListener("touchstart", onTouchStart, { passive: true });
    document.addEventListener("touchmove", preventPullToRefresh, { passive: false });

    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type !== "SYNC_OFFLINE_TRIPS") {
        return;
      }

      try {
        const offlineTrips = JSON.parse(localStorage.getItem("offline_trips") || "[]");
        if (Array.isArray(offlineTrips) && offlineTrips.length > 0) {
          console.log("Syncing offline trips:", offlineTrips.length);
        }
      } catch (error) {
        console.warn("Failed to parse offline trips:", error);
      }
    };

    navigator.serviceWorker?.addEventListener("message", handleMessage);

    return () => {
      document.removeEventListener("touchend", preventDoubleTapZoom);
      document.removeEventListener("touchstart", onTouchStart);
      document.removeEventListener("touchmove", preventPullToRefresh);
      navigator.serviceWorker?.removeEventListener("message", handleMessage);
    };
  }, []);

  if (isDriverPortal) {
    return null;
  }

  return <SiteAIAgent />;
}
