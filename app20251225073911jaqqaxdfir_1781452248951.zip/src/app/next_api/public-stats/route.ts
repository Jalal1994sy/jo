
import CrudOperations from '@/lib/crud-operations';
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { requestMiddleware } from '@/lib/api-utils';
import { generateAdminUserToken } from '@/lib/auth';

export const GET = requestMiddleware(async () => {
  try {
    const adminToken = await generateAdminUserToken();

    const driversCrud = new CrudOperations('drivers', adminToken);
    const companiesCrud = new CrudOperations('companies', adminToken);
    const tripsCrud = new CrudOperations('trips', adminToken);
    const invoicesCrud = new CrudOperations('invoices', adminToken);

    const [allDrivers, allCompanies, allTrips, allInvoices] = await Promise.all([
      driversCrud.findMany({ status: 'active' }, { limit: 10000 }),
      companiesCrud.findMany({}, { limit: 10000 }),
      tripsCrud.findMany({ status: 'completed' }, { limit: 100000 }),
      invoicesCrud.findMany({}, { limit: 100000 }),
    ]);

    const activeDriversCount = Array.isArray(allDrivers) ? allDrivers.length : 0;
    const companiesCount = Array.isArray(allCompanies) ? allCompanies.length : 0;
    const completedTripsCount = Array.isArray(allTrips) ? allTrips.length : 0;
    const invoicesCount = Array.isArray(allInvoices) ? allInvoices.length : 0;

    // Calculate total revenue from invoices
    const totalRevenue = Array.isArray(allInvoices)
      ? allInvoices.reduce((sum: number, inv: any) => sum + (parseFloat(inv?.total_tvac) || 0), 0)
      : 0;

    // Count paid invoices
    const paidInvoices = Array.isArray(allInvoices)
      ? allInvoices.filter((inv: any) => inv?.payment_status === 'paid').length
      : 0;

    // Count airport trips
    const airportTrips = Array.isArray(allTrips)
      ? allTrips.filter((t: any) => t?.is_airport_trip === true).length
      : 0;

    // Count night trips
    const nightTrips = Array.isArray(allTrips)
      ? allTrips.filter((t: any) => t?.is_night_trip === true).length
      : 0;

    return createSuccessResponse({
      activeDrivers: activeDriversCount,
      companies: companiesCount,
      completedTrips: completedTripsCount,
      invoicesCount,
      totalRevenue: Math.round(totalRevenue),
      paidInvoices,
      airportTrips,
      nightTrips,
      satisfactionRate: 99,
    });
  } catch (error) {
    console.error('Failed to fetch public stats:', error);
    return createErrorResponse({
      errorMessage: 'Failed to fetch statistics',
      status: 500,
    });
  }
}, false);
