
import CrudOperations from "@/lib/crud-operations";
import { createSuccessResponse, createErrorResponse } from "@/lib/create-response";
import { requestMiddleware, parseQueryParams } from "@/lib/api-utils";
import { generateAdminUserToken } from "@/lib/auth";

async function getManagerCompanyId(userId: string, adminToken: string) {
  const companyUsersCrud = new CrudOperations("company_users", adminToken);
  const links = await companyUsersCrud.findMany({ user_id: parseInt(userId) });

  if (!links || links.length === 0) {
    return null;
  }

  return links[0]?.company_id || null;
}

function getPeriodRange(period: string | null) {
  const endDate = new Date();
  const startDate = new Date();

  switch (period) {
    case "daily":
      startDate.setHours(0, 0, 0, 0);
      break;
    case "weekly":
      startDate.setDate(startDate.getDate() - 7);
      break;
    case "yearly":
      startDate.setFullYear(startDate.getFullYear() - 1);
      break;
    default:
      startDate.setMonth(startDate.getMonth() - 1);
      break;
  }

  return {
    startDate,
    endDate,
  };
}

function isDateInRange(value: string | null | undefined, startDate: Date, endDate: Date) {
  if (!value) {
    return false;
  }

  const date = new Date(value);
  return date >= startDate && date <= endDate;
}

function sumValues(items: any[], key: string) {
  return items.reduce((total, item) => total + Number(item?.[key] || 0), 0);
}

export const GET = requestMiddleware(async (request, context) => {
  const user_id = context.payload?.sub;
  const { period } = parseQueryParams(request);

  if (!user_id) {
    return createErrorResponse({ errorMessage: "User ID required", status: 400 });
  }

  try {
    const adminToken = await generateAdminUserToken();
    const company_id = await getManagerCompanyId(user_id, adminToken);

    if (!company_id) {
      return createErrorResponse({
        errorMessage: "No company linked to this account",
        status: 404,
      });
    }

    const companiesCrud = new CrudOperations("companies", adminToken);
    const company = await companiesCrud.findById(company_id);

    if (!company) {
      return createErrorResponse({ errorMessage: "Company not found", status: 404 });
    }

    const driversCrud = new CrudOperations("drivers", adminToken);
    const vehiclesCrud = new CrudOperations("vehicles", adminToken);
    const tripsCrud = new CrudOperations("trips", adminToken);
    const expensesCrud = new CrudOperations("expenses", adminToken);
    const invoicesCrud = new CrudOperations("invoices", adminToken);

    const [drivers, vehicles, trips, expenses, invoices] = await Promise.all([
      driversCrud.findMany({ company_id }, { limit: 10000, offset: 0 }),
      vehiclesCrud.findMany({ company_id }, { limit: 10000, offset: 0 }),
      tripsCrud.findMany({ company_id }, { limit: 10000, offset: 0 }),
      expensesCrud.findMany({ company_id }, { limit: 10000, offset: 0 }),
      invoicesCrud.findMany({ issuer_company_id: company_id }, { limit: 10000, offset: 0 }),
    ]);

    const { startDate, endDate } = getPeriodRange(period);
    const filteredTrips = (trips || []).filter((trip: any) => {
      const validStatus = trip?.status === "completed" || trip?.status === "success";
      return validStatus && isDateInRange(trip?.start_time, startDate, endDate);
    });

    const filteredExpenses = (expenses || []).filter((expense: any) => {
      const allowedStatus = !expense?.expense_status || !["cancelled", "rejected"].includes(expense.expense_status);
      return allowedStatus && isDateInRange(expense?.expense_date, startDate, endDate);
    });

    const filteredInvoices = (invoices || []).filter((invoice: any) => {
      const paid = invoice?.payment_status === "paid" || invoice?.status === "paid";
      return paid && isDateInRange(invoice?.invoice_date, startDate, endDate);
    });

    const tripsRevenue = sumValues(filteredTrips, "price");
    const subscriptionsRevenue = sumValues(
      filteredInvoices.filter((invoice: any) => invoice?.invoice_category === "company"),
      "total_tvac"
    );
    const expensesTotal = sumValues(filteredExpenses, "amount");
    const tripsCount = filteredTrips.length;
    const profits = tripsRevenue + subscriptionsRevenue - expensesTotal;

    const expensesByStatus = filteredExpenses.reduce((acc: Record<string, number>, item: any) => {
      const key = item?.expense_status || "draft";
      acc[key] = (acc[key] || 0) + Number(item?.amount || 0);
      return acc;
    }, {});

    const revenueByPaymentMethod = filteredTrips.reduce((acc: Record<string, number>, item: any) => {
      const key = item?.payment_method || "unknown";
      acc[key] = (acc[key] || 0) + Number(item?.price || 0);
      return acc;
    }, {});

    return createSuccessResponse({
      company,
      drivers: drivers || [],
      vehicles: vehicles || [],
      finance: {
        period: period || "monthly",
        start_date: startDate.toISOString(),
        end_date: endDate.toISOString(),
        totals: {
          revenue: Number(tripsRevenue.toFixed(2)),
          subscriptions: Number(subscriptionsRevenue.toFixed(2)),
          expenses: Number(expensesTotal.toFixed(2)),
          profits: Number(profits.toFixed(2)),
          trips: tripsCount,
          invoices: filteredInvoices.length,
        },
        expenses_by_status: expensesByStatus,
        revenue_by_payment_method: revenueByPaymentMethod,
        latest_expenses: filteredExpenses
          .sort((a: any, b: any) => new Date(b?.expense_date).getTime() - new Date(a?.expense_date).getTime())
          .slice(0, 8),
        latest_trips: filteredTrips
          .sort((a: any, b: any) => new Date(b?.start_time).getTime() - new Date(a?.start_time).getTime())
          .slice(0, 8),
      },
    });
  } catch (error: any) {
    console.error("Error fetching company portal data:", error);
    return createErrorResponse({
      errorMessage: error.message || "Failed to load company data",
      status: 500,
    });
  }
}, true);
