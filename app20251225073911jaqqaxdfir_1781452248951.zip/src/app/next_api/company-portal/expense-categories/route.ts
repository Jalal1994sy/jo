
import CrudOperations from "@/lib/crud-operations";
import { createSuccessResponse, createErrorResponse } from "@/lib/create-response";
import { requestMiddleware, validateRequestBody } from "@/lib/api-utils";
import { generateAdminUserToken } from "@/lib/auth";

async function getManagerCompanyId(userId: string, adminToken: string) {
  const companyUsersCrud = new CrudOperations("company_users", adminToken);
  const links = await companyUsersCrud.findMany({ user_id: parseInt(userId) });
  return links?.[0]?.company_id || null;
}

export const GET = requestMiddleware(async (_request, context) => {
  const userId = context.payload?.sub;

  if (!userId) {
    return createErrorResponse({ errorMessage: "Unauthorized", status: 401 });
  }

  try {
    const adminToken = await generateAdminUserToken();
    const companyId = await getManagerCompanyId(userId, adminToken);

    if (!companyId) {
      return createErrorResponse({ errorMessage: "No company linked", status: 403 });
    }

    const categoriesCrud = new CrudOperations("expense_categories", adminToken);
    const systemCategories = await categoriesCrud.findMany({ scope: "system", is_active: true }, { limit: 500, offset: 0 });
    const companyCategories = await categoriesCrud.findMany({ scope: "company", company_id: companyId, is_active: true }, { limit: 500, offset: 0 });

    const data = [...(systemCategories || []), ...(companyCategories || [])].sort((a: any, b: any) =>
      String(a?.name || "").localeCompare(String(b?.name || ""))
    );

    return createSuccessResponse(data);
  } catch (error: any) {
    console.error("Error loading expense categories:", error);
    return createErrorResponse({
      errorMessage: error.message || "Failed to load expense categories",
      status: 500,
    });
  }
}, true);

export const POST = requestMiddleware(async (request, context) => {
  const userId = context.payload?.sub;

  if (!userId) {
    return createErrorResponse({ errorMessage: "Unauthorized", status: 401 });
  }

  try {
    const body = await validateRequestBody(request);

    if (!body?.code || !body?.name) {
      return createErrorResponse({ errorMessage: "code and name are required", status: 400 });
    }

    const adminToken = await generateAdminUserToken();
    const companyId = await getManagerCompanyId(userId, adminToken);

    if (!companyId) {
      return createErrorResponse({ errorMessage: "No company linked", status: 403 });
    }

    const categoriesCrud = new CrudOperations("expense_categories", adminToken);
    const created = await categoriesCrud.create({
      company_id: companyId,
      code: String(body.code).trim().toUpperCase(),
      name: String(body.name).trim(),
      description: body.description || null,
      scope: "company",
      is_active: true,
    });

    return createSuccessResponse(created, 201);
  } catch (error: any) {
    console.error("Error creating expense category:", error);
    return createErrorResponse({
      errorMessage: error.message || "Failed to create expense category",
      status: 500,
    });
  }
}, true);
