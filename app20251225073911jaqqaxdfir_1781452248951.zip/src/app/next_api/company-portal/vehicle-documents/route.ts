
import CrudOperations from "@/lib/crud-operations";
import { createSuccessResponse, createErrorResponse } from "@/lib/create-response";
import { requestMiddleware, parseQueryParams, validateRequestBody } from "@/lib/api-utils";
import { generateAdminUserToken } from "@/lib/auth";
import { assertPositiveInteger } from "@/lib/security";

const VALID_DOCUMENT_TYPES = [
  "controle_technique",
  "assurance",
  "certificat_immatriculation",
  "vignette_taxi",
];

async function getManagerCompanyId(userId: string, adminToken: string) {
  const companyUsersCrud = new CrudOperations("company_users", adminToken);
  const links = await companyUsersCrud.findMany({ user_id: parseInt(userId) });
  return links?.[0]?.company_id || null;
}

async function getScopedVehicle(params: {
  adminToken: string;
  companyId: number;
  vehicleId: number;
}) {
  const vehiclesCrud = new CrudOperations("vehicles", params.adminToken);
  const vehicle = await vehiclesCrud.findById(params.vehicleId);

  if (!vehicle || vehicle?.company_id !== params.companyId) {
    return null;
  }

  return vehicle;
}

export const GET = requestMiddleware(async (request, context) => {
  const userId = context.payload?.sub;
  const { vehicle_id } = parseQueryParams(request);

  if (!userId) {
    return createErrorResponse({ errorMessage: "Unauthorized", status: 401 });
  }

  try {
    const adminToken = await generateAdminUserToken();
    const companyId = await getManagerCompanyId(userId, adminToken);

    if (!companyId) {
      return createErrorResponse({ errorMessage: "No company linked", status: 403 });
    }

    const docsCrud = new CrudOperations("vehicle_documents", adminToken);
    const allDocs = await docsCrud.findMany({ company_id: companyId }, { limit: 10000, offset: 0 });

    const filteredDocs = vehicle_id
      ? (allDocs || []).filter((item: any) => item?.vehicle_id === parseInt(vehicle_id))
      : allDocs || [];

    return createSuccessResponse(filteredDocs);
  } catch (error: any) {
    console.error("Error fetching vehicle documents:", error);
    return createErrorResponse({
      errorMessage: error.message || "Failed to load vehicle documents",
      status: 500,
    });
  }
}, true);

export const POST = requestMiddleware(async (request, context) => {
  const userId = context.payload?.sub;

  if (!userId) {
    return createErrorResponse({ errorMessage: "Unauthorized", status: 401 });
  }

  try {
    const body = await validateRequestBody(request);
    const adminToken = await generateAdminUserToken();
    const companyId = await getManagerCompanyId(userId, adminToken);

    if (!companyId) {
      return createErrorResponse({ errorMessage: "No company linked", status: 403 });
    }

    const vehicleId = assertPositiveInteger(body?.vehicle_id, "vehicle_id");

    if (!VALID_DOCUMENT_TYPES.includes(body?.document_type)) {
      return createErrorResponse({ errorMessage: "Invalid document_type", status: 400 });
    }

    if (!body?.file_name || !body?.file_url || !body?.file_key) {
      return createErrorResponse({
        errorMessage: "file_name, file_url and file_key are required",
        status: 400,
      });
    }

    const vehicle = await getScopedVehicle({
      adminToken,
      companyId,
      vehicleId,
    });

    if (!vehicle) {
      return createErrorResponse({ errorMessage: "Vehicle not found", status: 404 });
    }

    const docsCrud = new CrudOperations("vehicle_documents", adminToken);
    const existingCurrent = await docsCrud.findMany({
      vehicle_id: vehicleId,
      document_type: body.document_type,
      is_current: true,
    });

    for (const item of existingCurrent || []) {
      await docsCrud.update(item.id, {
        is_current: false,
        updated_at: new Date().toISOString(),
      });
    }

    const created = await docsCrud.create({
      vehicle_id: vehicleId,
      company_id: companyId,
      document_type: body.document_type,
      file_name: body.file_name,
      file_url: body.file_url,
      file_mime_type: "application/pdf",
      file_size_bytes: body.file_size_bytes || null,
      document_number: body.document_number || null,
      issued_date: body.issued_date || null,
      expiry_date: body.expiry_date || null,
      approval_status: "pending",
      is_current: true,
      locked_after_approval: false,
      uploaded_by_user_id: parseInt(userId),
      notes: body.notes || null,
    });

    return createSuccessResponse(created, 201);
  } catch (error: any) {
    console.error("Error creating vehicle document:", error);
    return createErrorResponse({
      errorMessage: error.message || "Failed to create vehicle document",
      status: 500,
    });
  }
}, true);

export const PUT = requestMiddleware(async (request, context) => {
  const userId = context.payload?.sub;
  const { id } = parseQueryParams(request);

  if (!userId) {
    return createErrorResponse({ errorMessage: "Unauthorized", status: 401 });
  }

  if (!id) {
    return createErrorResponse({ errorMessage: "Document ID is required", status: 400 });
  }

  try {
    const body = await validateRequestBody(request);
    const adminToken = await generateAdminUserToken();
    const companyId = await getManagerCompanyId(userId, adminToken);

    if (!companyId) {
      return createErrorResponse({ errorMessage: "No company linked", status: 403 });
    }

    const docsCrud = new CrudOperations("vehicle_documents", adminToken);
    const existing = await docsCrud.findById(id);

    if (!existing || existing?.company_id !== companyId) {
      return createErrorResponse({ errorMessage: "Document not found", status: 404 });
    }

    if (existing?.locked_after_approval || existing?.approval_status === "approved") {
      return createErrorResponse({
        errorMessage: "Approved documents are locked and cannot be edited",
        status: 409,
      });
    }

    const updateData: Record<string, any> = {
      document_number: body?.document_number || null,
      issued_date: body?.issued_date || null,
      expiry_date: body?.expiry_date || null,
      notes: body?.notes || null,
      updated_at: new Date().toISOString(),
    };

    const updated = await docsCrud.update(id, updateData);
    return createSuccessResponse(updated);
  } catch (error: any) {
    console.error("Error updating vehicle document:", error);
    return createErrorResponse({
      errorMessage: error.message || "Failed to update vehicle document",
      status: 500,
    });
  }
}, true);

export const DELETE = requestMiddleware(async (request, context) => {
  const userId = context.payload?.sub;
  const { id } = parseQueryParams(request);

  if (!userId) {
    return createErrorResponse({ errorMessage: "Unauthorized", status: 401 });
  }

  if (!id) {
    return createErrorResponse({ errorMessage: "Document ID is required", status: 400 });
  }

  try {
    const adminToken = await generateAdminUserToken();
    const companyId = await getManagerCompanyId(userId, adminToken);

    if (!companyId) {
      return createErrorResponse({ errorMessage: "No company linked", status: 403 });
    }

    const docsCrud = new CrudOperations("vehicle_documents", adminToken);
    const existing = await docsCrud.findById(id);

    if (!existing || existing?.company_id !== companyId) {
      return createErrorResponse({ errorMessage: "Document not found", status: 404 });
    }

    if (existing?.locked_after_approval || existing?.approval_status === "approved") {
      return createErrorResponse({
        errorMessage: "Approved documents are locked and cannot be deleted",
        status: 409,
      });
    }

    await docsCrud.delete(id);
    return createSuccessResponse({ id });
  } catch (error: any) {
    console.error("Error deleting vehicle document:", error);
    return createErrorResponse({
      errorMessage: error.message || "Failed to delete vehicle document",
      status: 500,
    });
  }
}, true);
