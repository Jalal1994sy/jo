
import CrudOperations from '@/lib/crud-operations';
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { requestMiddleware, parseQueryParams, validateRequestBody } from "@/lib/api-utils";
import { generateAdminUserToken } from '@/lib/auth';
import { getEntityDisplayName, prepareJsonbValue, prepareUpdatePayload } from '@/lib/database-json';

// GET - Fetch vehicles (admin sees all, distributor sees only their companies' vehicles)
export const GET = requestMiddleware(async (request, context) => {
  const { limit, offset, company_id } = parseQueryParams(request);

  try {
    const adminToken = await generateAdminUserToken();
    const vehiclesCrud = new CrudOperations("vehicles", adminToken);

    const filters: Record<string, any> = {};

    if (!context.payload?.isAdmin) {
      const distributorsCrud = new CrudOperations("distributors", adminToken);
      const distributors = await distributorsCrud.findMany({
        user_id: parseInt(context.payload?.sub || '0')
      });

      if (distributors && distributors.length > 0) {
        const distributor_id = distributors[0].id;

        const distributorCompaniesCrud = new CrudOperations("distributor_companies", adminToken);
        const assignments = await distributorCompaniesCrud.findMany({
          distributor_id,
          is_active: true
        });

        if (!assignments || assignments.length === 0) {
          return createSuccessResponse([]);
        }

        const companyIds = assignments.map((assignment: any) => assignment.company_id);
        const allVehicles = [];
        for (const currentCompanyId of companyIds) {
          const companyVehicles = await vehiclesCrud.findMany(
            { company_id: currentCompanyId },
            { limit: 10000, offset: 0 }
          );
          if (companyVehicles) {
            allVehicles.push(...companyVehicles);
          }
        }

        return createSuccessResponse(allVehicles);
      }

      return createSuccessResponse([]);
    }

    if (company_id) {
      filters.company_id = company_id;
    }

    const data = await vehiclesCrud.findMany(
      filters,
      {
        limit: limit > 10 ? limit : 10000,
        offset: offset || 0,
        orderBy: {
          column: 'created_at',
          direction: 'desc'
        }
      }
    );

    return createSuccessResponse(data);
  } catch (error: any) {
    console.error('Error fetching vehicles:', error);
    return createErrorResponse({
      errorMessage: error.message || "Failed to fetch vehicles",
      status: 500,
    });
  }
}, true);

// POST - Create new vehicle (admin and distributor can create)
export const POST = requestMiddleware(async (request, context) => {
  const body = await validateRequestBody(request);
  const { company_id, brand, model, plate_number, vin, chiron_vehicle_id, status } = body;

  if (!company_id || !brand || !model || !plate_number) {
    return createErrorResponse({
      errorMessage: "Required fields: company_id, brand, model, plate_number",
      status: 400,
    });
  }

  try {
    const adminToken = await generateAdminUserToken();

    if (!context.payload?.isAdmin) {
      const distributorsCrud = new CrudOperations("distributors", adminToken);
      const distributors = await distributorsCrud.findMany({
        user_id: parseInt(context.payload?.sub || '0')
      });

      if (!distributors || distributors.length === 0) {
        return createErrorResponse({
          errorMessage: "Access denied",
          status: 403,
        });
      }

      const distributor_id = distributors[0].id;

      const distributorCompaniesCrud = new CrudOperations("distributor_companies", adminToken);
      const assignments = await distributorCompaniesCrud.findMany({
        distributor_id,
        company_id: parseInt(company_id),
        is_active: true
      });

      if (!assignments || assignments.length === 0) {
        return createErrorResponse({
          errorMessage: "This company is not linked to your account",
          status: 403,
        });
      }
    }

    let created_by_distributor_id = null;
    if (!context.payload?.isAdmin) {
      const distributorsCrud = new CrudOperations("distributors", adminToken);
      const distributors = await distributorsCrud.findMany({
        user_id: parseInt(context.payload?.sub || '0')
      });

      if (distributors && distributors.length > 0) {
        created_by_distributor_id = distributors[0].id;
      }
    }

    const vehiclesCrud = new CrudOperations("vehicles", adminToken);
    const data = await vehiclesCrud.create({
      company_id,
      brand,
      model,
      plate_number,
      vin,
      chiron_vehicle_id,
      status: status || 'active',
      documents: [],
      created_by_distributor_id
    });

    return createSuccessResponse(data, 201);
  } catch (error: any) {
    console.error('Error creating vehicle:', error);
    return createErrorResponse({
      errorMessage: error.message || "Failed to create vehicle",
      status: 500,
    });
  }
}, true);

// PUT - Update vehicle (requires approval for distributors)
export const PUT = requestMiddleware(async (request, context) => {
  const { id } = parseQueryParams(request);

  if (!id) {
    return createErrorResponse({
      errorMessage: "Vehicle id is required",
      status: 400,
    });
  }

  const body = await validateRequestBody(request);

  try {
    const adminToken = await generateAdminUserToken();
    const vehiclesCrud = new CrudOperations("vehicles", adminToken);

    const existing = await vehiclesCrud.findById(id);
    if (!existing) {
      return createErrorResponse({
        errorMessage: "Vehicle not found",
        status: 404,
      });
    }

    const updateData = prepareUpdatePayload(body);

    if (!context.payload?.isAdmin) {
      const distributorsCrud = new CrudOperations("distributors", adminToken);
      const distributors = await distributorsCrud.findMany({
        user_id: parseInt(context.payload?.sub || '0')
      });

      if (!distributors || distributors.length === 0) {
        return createErrorResponse({
          errorMessage: "Access denied",
          status: 403,
        });
      }

      const distributor_id = distributors[0].id;
      const approvalRequestsCrud = new CrudOperations("approval_requests", adminToken);
      const approvalRequest = await approvalRequestsCrud.create({
        request_type: 'update',
        entity_type: 'vehicle',
        entity_id: id,
        requested_by_user_id: context.payload?.sub,
        distributor_id,
        request_data: prepareJsonbValue(updateData),
        current_data: prepareJsonbValue(existing),
        request_reason: 'Vehicle update request',
        status: 'pending',
        entity_name: getEntityDisplayName('vehicle', existing),
      });

      const approvalHistoryCrud = new CrudOperations("approval_history", adminToken);
      await approvalHistoryCrud.create({
        approval_request_id: approvalRequest.id,
        action: 'submitted',
        performed_by_user_id: context.payload?.sub,
        action_notes: 'Update request submitted',
        action_data: prepareJsonbValue({
          entity_type: 'vehicle',
          entity_id: id,
        }),
      });

      return createSuccessResponse({
        message: 'Update request sent for approval',
        approval_request_id: approvalRequest.id,
        status: 'pending_approval'
      });
    }

    const data = await vehiclesCrud.update(id, updateData);
    return createSuccessResponse(data);
  } catch (error: any) {
    console.error('Error updating vehicle:', error);
    return createErrorResponse({
      errorMessage: error.message || "Failed to update vehicle",
      status: 500,
    });
  }
}, true);

// DELETE - Delete vehicle (requires approval for distributors)
export const DELETE = requestMiddleware(async (request, context) => {
  const { id } = parseQueryParams(request);

  if (!id) {
    return createErrorResponse({
      errorMessage: "Vehicle id is required",
      status: 400,
    });
  }

  try {
    const adminToken = await generateAdminUserToken();
    const vehiclesCrud = new CrudOperations("vehicles", adminToken);

    const existing = await vehiclesCrud.findById(id);
    if (!existing) {
      return createErrorResponse({
        errorMessage: "Vehicle not found",
        status: 404,
      });
    }

    if (!context.payload?.isAdmin) {
      const distributorsCrud = new CrudOperations("distributors", adminToken);
      const distributors = await distributorsCrud.findMany({
        user_id: parseInt(context.payload?.sub || '0')
      });

      if (!distributors || distributors.length === 0) {
        return createErrorResponse({
          errorMessage: "Access denied",
          status: 403,
        });
      }

      const distributor_id = distributors[0].id;
      const approvalRequestsCrud = new CrudOperations("approval_requests", adminToken);
      const approvalRequest = await approvalRequestsCrud.create({
        request_type: 'delete',
        entity_type: 'vehicle',
        entity_id: id,
        requested_by_user_id: context.payload?.sub,
        distributor_id,
        request_data: prepareJsonbValue({}),
        current_data: prepareJsonbValue(existing),
        request_reason: 'Vehicle delete request',
        status: 'pending',
        entity_name: getEntityDisplayName('vehicle', existing),
      });

      const approvalHistoryCrud = new CrudOperations("approval_history", adminToken);
      await approvalHistoryCrud.create({
        approval_request_id: approvalRequest.id,
        action: 'submitted',
        performed_by_user_id: context.payload?.sub,
        action_notes: 'Delete request submitted',
        action_data: prepareJsonbValue({
          entity_type: 'vehicle',
          entity_id: id,
        }),
      });

      return createSuccessResponse({
        message: 'Delete request sent for approval',
        approval_request_id: approvalRequest.id,
        status: 'pending_approval'
      });
    }

    const data = await vehiclesCrud.delete(id);
    return createSuccessResponse(data);
  } catch (error: any) {
    console.error('Error deleting vehicle:', error);
    return createErrorResponse({
      errorMessage: error.message || "Failed to delete vehicle",
      status: 500,
    });
  }
}, true);
