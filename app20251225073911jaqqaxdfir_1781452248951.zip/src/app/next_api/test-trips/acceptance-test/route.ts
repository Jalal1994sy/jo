
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { requestMiddleware, validateRequestBody } from "@/lib/api-utils";
import { ChironService } from '@/lib/chiron-service';
import CrudOperations from '@/lib/crud-operations';
import { generateAdminUserToken } from '@/lib/auth';
import { PDFGenerator } from '@/lib/pdf-generator';
import { upload } from '@zoerai/integration';

export const POST = requestMiddleware(async (request, context) => {
  try {
    const body = await validateRequestBody(request);
    const { company_id, driver_id, vehicle_id } = body;

    if (!company_id || !driver_id || !vehicle_id) {
      return createErrorResponse({
        errorMessage: "company_id, driver_id and vehicle_id are required",
        status: 400,
      });
    }

    const adminToken = await generateAdminUserToken();

    const companiesCrud = new CrudOperations('companies', adminToken);
    const company = await companiesCrud.findById(company_id);

    if (!company) {
      return createErrorResponse({
        errorMessage: "Company not found",
        status: 404,
      });
    }

    const driversCrud = new CrudOperations('drivers', adminToken);
    const driver = await driversCrud.findById(driver_id);

    if (!driver) {
      return createErrorResponse({
        errorMessage: "Driver not found",
        status: 404,
      });
    }

    const vehiclesCrud = new CrudOperations('vehicles', adminToken);
    const vehicle = await vehiclesCrud.findById(vehicle_id);

    if (!vehicle) {
      return createErrorResponse({
        errorMessage: "Vehicle not found",
        status: 404,
      });
    }

    const result = await ChironService.runAcceptanceTest(
      parseInt(company_id),
      parseInt(driver_id),
      parseInt(vehicle_id)
    );

    let pdfUrl: string | null = null;

    try {
      const pdfDoc = PDFGenerator.generateAcceptanceTestReport({
        company: {
          id: company?.id,
          name: company?.name,
          kbo_number: company?.kbo_number || '',
          address: company?.address || '',
          email: company?.email || '',
          phone: company?.phone || '',
          vat_number: company?.vat_number || '',
        },
        driver: {
          id: driver?.id,
          full_name: driver?.full_name,
          capacity_certificate_number: driver?.capacity_certificate_number || '',
          phone: driver?.phone || '',
        },
        vehicle: {
          id: vehicle?.id,
          brand: vehicle?.brand,
          model: vehicle?.model,
          plate_number: vehicle?.plate_number,
        },
        testDate: new Date().toISOString(),
        totalMessages: result?.totalMessages,
        successCount: result?.successCount,
        failedCount: result?.failedCount,
        results: result?.results || []
      });

      const pdfBlob = PDFGenerator.getPDFBlob(pdfDoc);
      const pdfFile = new File(
        [pdfBlob],
        `acceptance-test-${company_id}-${Date.now()}.pdf`,
        { type: 'application/pdf' }
      );

      const uploadResult = await upload.uploadWithPresignedUrl(pdfFile, {
        maxSize: 5 * 1024 * 1024,
        allowedExtensions: ['.pdf']
      });

      if (uploadResult?.success && uploadResult?.url) {
        pdfUrl = uploadResult.url;
      }
    } catch (pdfError: any) {
      console.error('[Acceptance Test] PDF generation failed:', pdfError);
    }

    const reportsCrud = new CrudOperations('acceptance_test_reports', adminToken);
    const testTripIds = Array.isArray(result?.results)
      ? result.results
          .map((item: any) => item?.trip_id)
          .filter((value: number | null | undefined) => typeof value === 'number')
      : [];

    await reportsCrud.create({
      company_id: parseInt(company_id),
      driver_id: parseInt(driver_id),
      report_date: new Date().toISOString().split('T')[0],
      total_messages: result?.totalMessages || 0,
      success_count: result?.successCount || 0,
      failed_count: result?.failedCount || 0,
      vertrek_count: 5,
      aankomst_count: 5,
      test_trip_ids: testTripIds,
      report_status: result?.success ? 'completed' : 'failed',
      report_pdf_url: pdfUrl,
      submitted_to_municipality: false,
      notes: result?.success
        ? 'Acceptance test completed successfully'
        : `Acceptance test completed with ${result?.failedCount || 0} failed messages`,
    });

    return createSuccessResponse(
      {
        message: result?.success
          ? "Acceptance test completed successfully"
          : "Acceptance test finished with some failed messages",
        pdfUrl,
        ...result,
      },
      result?.success ? 201 : 200
    );
  } catch (error: any) {
    console.error('Error running acceptance test:', error);
    return createErrorResponse({
      errorMessage: error?.message || "Failed to run acceptance test",
      status: 500,
    });
  }
}, true);
