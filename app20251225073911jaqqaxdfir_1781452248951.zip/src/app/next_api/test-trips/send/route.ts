
import CrudOperations from '@/lib/crud-operations';
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { requestMiddleware, validateRequestBody } from "@/lib/api-utils";
import { generateAdminUserToken } from '@/lib/auth';

export const POST = requestMiddleware(async (request, context) => {
  const body = await validateRequestBody(request);
  const { company_id } = body;

  if (!company_id) {
    return createErrorResponse({
      errorMessage: "Company id is required",
      status: 400,
    });
  }

  try {
    const adminToken = await generateAdminUserToken();

    const chironSettingsCrud = new CrudOperations("chiron_settings", adminToken);
    const chironSettings = await chironSettingsCrud.findMany({ company_id: parseInt(company_id) });

    if (!chironSettings || chironSettings.length === 0) {
      return createErrorResponse({
        errorMessage: "Chiron settings not found",
        status: 404,
      });
    }

    const settings = chironSettings[0];

    const companiesCrud = new CrudOperations("companies", adminToken);
    const company = await companiesCrud.findById(company_id);

    if (!company) {
      return createErrorResponse({
        errorMessage: "Company not found",
        status: 404,
      });
    }

    const chironMode = String(company?.chiron_mode || '').toLowerCase();
    if (chironMode !== 'test') {
      return createErrorResponse({
        errorMessage: "Company must use test mode before sending acceptance trips",
        status: 400,
      });
    }

    const testTripsCrud = new CrudOperations("test_trips", adminToken);
    const pendingTrips = await testTripsCrud.findMany({
      company_id: parseInt(company_id),
      sync_status: 'pending'
    });

    if (!pendingTrips || pendingTrips.length === 0) {
      return createErrorResponse({
        errorMessage: "No pending acceptance trips found",
        status: 404,
      });
    }

    let testToken = settings?.test_token;
    const now = new Date();

    if (!testToken || !settings?.test_token_expires_at || new Date(settings.test_token_expires_at) <= now) {
      const tokenResponse = await fetch(company?.chiron_test_auth_url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          grant_type: 'client_credentials',
          client_id: company?.chiron_test_client_id || '',
          client_secret: company?.chiron_test_client_secret || '',
          scope: 'chiron.taxi'
        })
      });

      if (!tokenResponse.ok) {
        const errorText = await tokenResponse.text();
        return createErrorResponse({
          errorMessage: `Failed to fetch test token: ${errorText}`,
          status: 500,
        });
      }

      const tokenData = await tokenResponse.json();
      testToken = tokenData?.access_token;

      await chironSettingsCrud.update(settings.id, {
        test_token: testToken,
        test_token_expires_at: new Date(Date.now() + tokenData.expires_in * 1000).toISOString()
      });
    }

    const results = [];
    let successCount = 0;
    let failedCount = 0;

    for (const trip of pendingTrips) {
      try {
        const messageType = String(trip?.message_type || '').toLowerCase();
        const payload: Record<string, any> = {
          status: messageType,
          ritnummer: trip?.ritnummer,
          bestuurder: {
            id: trip?.chiron_driver_id
          },
          voertuig: {
            id: trip?.chiron_vehicle_id
          },
          tijdstip: trip?.timestamp
        };

        if (messageType === 'vertrek') {
          payload.vertrekpunt = {
            latitude: trip?.start_lat,
            longitude: trip?.start_lon
          };
        } else {
          payload.aankomstpunt = {
            latitude: trip?.end_lat,
            longitude: trip?.end_lon
          };
          payload.afstand = trip?.distance_km;
          payload.kostprijs = trip?.price;
        }

        const response = await fetch(company?.chiron_test_api_url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${testToken}`
          },
          body: JSON.stringify(payload)
        });

        const responseData = await response.json();

        if (response.ok) {
          await testTripsCrud.update(trip.id, {
            sync_status: 'success',
            request_payload: payload,
            response_payload: responseData,
            http_status_code: response.status,
            error_message: null,
            updated_at: new Date().toISOString(),
          });
          successCount++;
          results.push({ trip_id: trip.id, status: 'success' });
        } else {
          await testTripsCrud.update(trip.id, {
            sync_status: 'failed',
            request_payload: payload,
            response_payload: responseData,
            error_message: typeof responseData === 'string' ? responseData : JSON.stringify(responseData),
            http_status_code: response.status,
            updated_at: new Date().toISOString(),
          });
          failedCount++;
          results.push({ trip_id: trip.id, status: 'failed', error: responseData });
        }
      } catch (error: any) {
        await testTripsCrud.update(trip.id, {
          sync_status: 'failed',
          error_message: error?.message || 'Unknown error',
          updated_at: new Date().toISOString(),
        });
        failedCount++;
        results.push({
          trip_id: trip.id,
          status: 'failed',
          error: error?.message || 'Unknown error'
        });
      }
    }

    return createSuccessResponse({
      message: "Acceptance trips processed",
      total: pendingTrips.length,
      success: successCount,
      failed: failedCount,
      results
    });
  } catch (error: any) {
    console.error('Error sending test trips:', error);
    return createErrorResponse({
      errorMessage: error?.message || "Failed to send acceptance trips",
      status: 500,
    });
  }
}, true);
