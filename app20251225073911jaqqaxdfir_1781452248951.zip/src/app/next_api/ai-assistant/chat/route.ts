
import { requestMiddleware, validateRequestBody } from "@/lib/api-utils";
import { createSuccessResponse, createErrorResponse } from "@/lib/create-response";
import { generateAdminUserToken } from "@/lib/auth";
import CrudOperations from "@/lib/crud-operations";

const NOTIFICATION_EMAIL = "ezetdin@gmail.com";

async function sendNotificationEmail(
  actionDescription: string,
  details: any,
  status: "proposed" | "executed" | "rejected"
) {
  const statusLabel =
    status === "proposed"
      ? "🔔 New Action Proposed"
      : status === "executed"
      ? "✅ Action Executed"
      : "❌ Action Rejected";
  const statusColor =
    status === "proposed" ? "#f59e0b" : status === "executed" ? "#10b981" : "#ef4444";

  const html = `
    <div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px;background:#f9fafb;border-radius:12px;">
      <div style="background:linear-gradient(135deg,#7c3aed,#a855f7);padding:20px;border-radius:10px;margin-bottom:20px;">
        <h2 style="color:#fff;margin:0;font-size:18px;">🤖 AI Assistant Notification</h2>
        <p style="color:#e9d5ff;margin:6px 0 0;font-size:13px;">Taximeter Platform - Smart Assistant</p>
      </div>
      <div style="background:#fff;padding:20px;border-radius:10px;border-left:4px solid ${statusColor};margin-bottom:16px;">
        <h3 style="color:${statusColor};margin:0 0 8px;">${statusLabel}</h3>
        <p style="color:#374151;font-size:14px;margin:0;"><strong>Action:</strong> ${actionDescription}</p>
      </div>
      <div style="background:#fff;padding:16px;border-radius:10px;margin-bottom:16px;">
        <h4 style="color:#6b7280;font-size:12px;text-transform:uppercase;margin:0 0 10px;">Details</h4>
        <pre style="background:#f3f4f6;padding:12px;border-radius:8px;overflow:auto;font-size:12px;color:#1f2937;">${JSON.stringify(details, null, 2)}</pre>
      </div>
      <p style="color:#9ca3af;font-size:11px;text-align:center;margin:0;">Sent at: ${new Date().toLocaleString("en-GB", { timeZone: "Europe/Brussels" })}</p>
    </div>
  `;

  const url = `${process.env.NEXT_PUBLIC_ZOER_HOST}/zapi/app/email/send`;
  try {
    await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Postgrest-API-Key": process.env.POSTGREST_API_KEY || "",
      },
      body: JSON.stringify({
        to: NOTIFICATION_EMAIL,
        subject: `[AI Assistant] ${statusLabel}: ${actionDescription}`,
        html,
      }),
    });
  } catch (e) {
    console.error("Failed to send notification email:", e);
  }
}

// Remove internal-only fields that should not be written to the target table
function sanitizeChanges(changes: Record<string, any>): Record<string, any> {
  const internalKeys = ["_admin_note", "_note", "_internal"];
  const sanitized: Record<string, any> = {};
  for (const [key, value] of Object.entries(changes)) {
    if (!internalKeys.includes(key)) {
      sanitized[key] = value;
    }
  }
  return sanitized;
}

export const POST = requestMiddleware(async (request) => {
  const body = await validateRequestBody(request);
  const { action } = body;
  const adminToken = await generateAdminUserToken();

  // ── Execute a confirmed action ──────────────────────────────────────────────
  if (action === "execute_action") {
    const { action_id } = body;
    if (!action_id) {
      return createErrorResponse({ errorMessage: "action_id is required", status: 400 });
    }

    const actionsCrud = new CrudOperations("ai_assistant_actions", adminToken);
    const actionRecord = await actionsCrud.findById(action_id);

    if (!actionRecord) {
      return createErrorResponse({ errorMessage: "Action not found", status: 404 });
    }

    if (actionRecord.status !== "pending") {
      return createErrorResponse({
        errorMessage: `Action is already in '${actionRecord.status}' state`,
        status: 400,
      });
    }

    const { target_table, target_record_id, proposed_changes } = actionRecord;
    const executedAt = new Date().toISOString();

    try {
      // Apply changes to the target table only if there are real DB fields to update
      if (target_table && target_record_id && target_record_id > 0) {
        const cleanChanges = sanitizeChanges(proposed_changes || {});
        if (Object.keys(cleanChanges).length > 0) {
          const targetCrud = new CrudOperations(target_table, adminToken);
          await targetCrud.update(target_record_id, cleanChanges);
        }
      }

      // Single update call — merge status + email_sent together to avoid double-update issues
      await actionsCrud.update(action_id, {
        status: "executed",
        confirmed_at: executedAt,
        executed_at: executedAt,
        email_sent: true,
        email_sent_at: executedAt,
        execution_details: {
          executed_at: executedAt,
          target_table,
          target_record_id,
          applied_changes: sanitizeChanges(proposed_changes || {}),
        },
      });

      // Send email notification (non-blocking — failure won't break the response)
      sendNotificationEmail(
        actionRecord.action_description,
        {
          action_id,
          target_table,
          target_record_id,
          proposed_changes,
          executed_at: executedAt,
        },
        "executed"
      ).catch((e) => console.error("Email notification failed:", e));

      return createSuccessResponse({ executed: true, action_id });
    } catch (err: any) {
      console.error("execute_action error:", err);

      // Mark as failed in a separate try so we don't lose the error info
      try {
        await actionsCrud.update(action_id, {
          status: "failed",
          execution_error: err?.message || "Unknown error",
          execution_details: { error: err?.message, failed_at: new Date().toISOString() },
        });
      } catch (updateErr) {
        console.error("Failed to mark action as failed:", updateErr);
      }

      return createErrorResponse({
        errorMessage: `Execution failed: ${err?.message || "Unknown error"}`,
        status: 500,
      });
    }
  }

  // ── Reject a proposed action ────────────────────────────────────────────────
  if (action === "reject_action") {
    const { action_id, reason } = body;
    if (!action_id) {
      return createErrorResponse({ errorMessage: "action_id is required", status: 400 });
    }

    const actionsCrud = new CrudOperations("ai_assistant_actions", adminToken);
    const actionRecord = await actionsCrud.findById(action_id);

    await actionsCrud.update(action_id, {
      status: "rejected",
      rejected_at: new Date().toISOString(),
      rejection_reason: reason || "User rejected from chat",
    });

    if (actionRecord) {
      sendNotificationEmail(
        actionRecord.action_description,
        {
          action_id,
          reason: reason || "User rejected",
          rejected_at: new Date().toISOString(),
        },
        "rejected"
      ).catch((e) => console.error("Email notification failed:", e));
    }

    return createSuccessResponse({ rejected: true });
  }

  // ── Propose a new action (requires user confirmation) ───────────────────────
  if (action === "propose_action") {
    const {
      conversation_id,
      action_type,
      action_description,
      target_table,
      target_record_id,
      before_data,
      proposed_changes,
      user_id,
    } = body;

    const validActionTypes = [
      "update_trip",
      "update_driver",
      "update_vehicle",
      "update_company",
      "cancel_trip",
      "change_trip_status",
      "update_payment",
      "other",
    ];

    const safeActionType = validActionTypes.includes(action_type) ? action_type : "other";

    const actionsCrud = new CrudOperations("ai_assistant_actions", adminToken);
    const newAction = await actionsCrud.create({
      conversation_id: conversation_id || 0,
      user_id: user_id || 0,
      action_type: safeActionType,
      action_description,
      target_table: target_table || null,
      target_record_id: target_record_id || null,
      before_data: before_data || {},
      proposed_changes: proposed_changes || {},
      status: "pending",
      notification_email: NOTIFICATION_EMAIL,
    });

    // Send proposal email (non-blocking)
    sendNotificationEmail(
      action_description,
      {
        action_id: newAction.id,
        action_type: safeActionType,
        target_table,
        target_record_id,
        proposed_changes,
        status: "pending - awaiting user confirmation",
      },
      "proposed"
    )
      .then(async () => {
        try {
          await actionsCrud.update(newAction.id, {
            email_sent: true,
            email_sent_at: new Date().toISOString(),
          });
        } catch (e) {
          console.error("Failed to mark email_sent:", e);
        }
      })
      .catch((e) => console.error("Email notification failed:", e));

    return createSuccessResponse(newAction);
  }

  return createErrorResponse({ errorMessage: "Invalid action type", status: 400 });
}, false);
