
import CrudOperations from "@/lib/crud-operations";
import { createSuccessResponse, createErrorResponse } from "@/lib/create-response";
import { requestMiddleware, parseQueryParams, validateRequestBody } from "@/lib/api-utils";
import { generateAdminUserToken } from "@/lib/auth";
import { assertPositiveInteger } from "@/lib/security";

async function getScopedCompanyId(context: any, requestedCompanyId?: string | null) {
  const adminToken = await generateAdminUserToken();

  if (context.payload?.isAdmin) {
    return {
      adminToken,
      companyId: requestedCompanyId ? parseInt(requestedCompanyId) : null,
    };
  }

  const userId = context.payload?.sub;
  if (!userId) {
    throw new Error("Unauthorized");
  }

  const companyUsersCrud = new CrudOperations("company_users", adminToken);
  const links = await companyUsersCrud.findMany({ user_id: parseInt(userId) });

  if (!links || links.length === 0) {
    const error = new Error("No company linked");
    (error as any).status = 403;
    throw error;
  }

  return {
    adminToken,
    companyId: links[0]?.company_id || null,
  };
}

async function attachRelatedData(expenses: any[], adminToken: string) {
  const attachmentsCrud = new CrudOperations("expense_attachments", adminToken);
  const categoriesCrud = new CrudOperations("expense_categories", adminToken);

  const allAttachments = await attachmentsCrud.findMany({}, { limit: 10000, offset: 0 });
  const allCategories = await categoriesCrud.findMany({}, { limit: 10000, offset: 0 });

  return (expenses || []).map((expense: any) => ({
    ...expense,
    attachments: (allAttachments || []).filter((item: any) => item?.expense_id === expense?.id),
    category: (allCategories || []).find((item: any) => item?.id === expense?.category_id) || null,
  }));
}

export const GET = requestMiddleware(async (request, context) => {
  const { limit, offset, company_id, status } = parseQueryParams(request);

  try {
    const scoped = await getScopedCompanyId(context, company_id);
    const expensesCrud = new CrudOperations("expenses", scoped.adminToken);

    const filters: Record<string, any> = {};
    if (scoped.companyId) {
      filters.company_id = scoped.companyId;
    }
    if (status) {
      filters.expense_status = status;
    }

    const expenses = await expensesCrud.findMany(filters, {
      limit: limit || 100,
      offset: offset || 0,
      orderBy: {
        column: "expense_date",
        direction: "desc",
      },
    });

    const data = await attachRelatedData(expenses || [], scoped.adminToken);
    return createSuccessResponse(data);
  } catch (error: any) {
    console.error("Error fetching expenses:", error);
    return createErrorResponse({
      errorMessage: error.message || "Failed to load expenses",
      status: error?.status || 500,
    });
  }
}, true);

export const POST = requestMiddleware(async (request, context) => {
  const body = await validateRequestBody(request);

  if (!body?.type || !body?.amount || !body?.expense_date) {
    return createErrorResponse({
      errorMessage: "type, amount and expense_date are required",
      status: 400,
    });
  }

  try {
    const scoped = await getScopedCompanyId(context, body?.company_id || null);
    const expensesCrud = new CrudOperations("expenses", scoped.adminToken);
    const attachmentsCrud = new CrudOperations("expense_attachments", scoped.adminToken);

    if (!scoped.companyId) {
      return createErrorResponse({ errorMessage: "company_id is required", status: 400 });
    }

    const amount = Number(body.amount);
    if (!Number.isFinite(amount) || amount <= 0) {
      return createErrorResponse({ errorMessage: "amount must be greater than zero", status: 400 });
    }

    const createdExpense = await expensesCrud.create({
      user_id: parseInt(context.payload?.sub || "0"),
      company_id: scoped.companyId,
      type: String(body.type).trim(),
      amount,
      expense_date: body.expense_date,
      description: body.description || null,
      receipt_url: body.receipt_url || null,
      category_id: body.category_id ? assertPositiveInteger(body.category_id, "category_id") : null,
      expense_status: body.expense_status || "draft",
    });

    const attachments = Array.isArray(body.attachments) ? body.attachments : [];
    for (const item of attachments) {
      if (!item?.file_name || !item?.file_url || !item?.file_key) {
        continue;
      }

      await attachmentsCrud.create({
        expense_id: createdExpense.id,
        company_id: scoped.companyId,
        uploaded_by_user_id: parseInt(context.payload?.sub || "0"),
        file_name: item.file_name,
        file_url: item.file_url,
        file_mime_type: "application/pdf",
        file_size_bytes: item.file_size_bytes || null,
        document_type: item.document_type || "receipt",
      });
    }

    const withRelations = await attachRelatedData([createdExpense], scoped.adminToken);
    return createSuccessResponse(withRelations[0], 201);
  } catch (error: any) {
    console.error("Error creating expense:", error);
    return createErrorResponse({
      errorMessage: error.message || "Failed to create expense",
      status: error?.status || 500,
    });
  }
}, true);

export const PUT = requestMiddleware(async (request, context) => {
  const { id } = parseQueryParams(request);

  if (!id) {
    return createErrorResponse({ errorMessage: "Expense ID is required", status: 400 });
  }

  try {
    const body = await validateRequestBody(request);
    const scoped = await getScopedCompanyId(context, null);
    const expensesCrud = new CrudOperations("expenses", scoped.adminToken);
    const attachmentsCrud = new CrudOperations("expense_attachments", scoped.adminToken);

    const existing = await expensesCrud.findById(id);
    if (!existing || (scoped.companyId && existing?.company_id !== scoped.companyId)) {
      return createErrorResponse({ errorMessage: "Expense not found", status: 404 });
    }

    if (existing?.expense_status === "approved" || existing?.expense_status === "paid") {
      return createErrorResponse({
        errorMessage: "Approved or paid expenses cannot be modified",
        status: 409,
      });
    }

    const updateData: Record<string, any> = {
      updated_at: new Date().toISOString(),
    };

    if (body?.type) {
      updateData.type = String(body.type).trim();
    }
    if (body?.amount !== undefined) {
      const amount = Number(body.amount);
      if (!Number.isFinite(amount) || amount <= 0) {
        return createErrorResponse({ errorMessage: "amount must be greater than zero", status: 400 });
      }
      updateData.amount = amount;
    }
    if (body?.expense_date) {
      updateData.expense_date = body.expense_date;
    }
    if (body?.description !== undefined) {
      updateData.description = body.description || null;
    }
    if (body?.expense_status) {
      updateData.expense_status = body.expense_status;
    }
    if (body?.category_id !== undefined) {
      updateData.category_id = body.category_id
        ? assertPositiveInteger(body.category_id, "category_id")
        : null;
    }

    const updatedExpense = await expensesCrud.update(id, updateData);

    const attachments = Array.isArray(body.attachments) ? body.attachments : [];
    for (const item of attachments) {
      if (!item?.file_name || !item?.file_url || !item?.file_key) {
        continue;
      }

      await attachmentsCrud.create({
        expense_id: updatedExpense.id,
        company_id: existing.company_id,
        uploaded_by_user_id: parseInt(context.payload?.sub || "0"),
        file_name: item.file_name,
        file_url: item.file_url,
        file_mime_type: "application/pdf",
        file_size_bytes: item.file_size_bytes || null,
        document_type: item.document_type || "receipt",
      });
    }

    const withRelations = await attachRelatedData([updatedExpense], scoped.adminToken);
    return createSuccessResponse(withRelations[0]);
  } catch (error: any) {
    console.error("Error updating expense:", error);
    return createErrorResponse({
      errorMessage: error.message || "Failed to update expense",
      status: error?.status || 500,
    });
  }
}, true);

export const DELETE = requestMiddleware(async (request, context) => {
  const { id } = parseQueryParams(request);

  if (!id) {
    return createErrorResponse({ errorMessage: "Expense ID is required", status: 400 });
  }

  try {
    const scoped = await getScopedCompanyId(context, null);
    const expensesCrud = new CrudOperations("expenses", scoped.adminToken);
    const attachmentsCrud = new CrudOperations("expense_attachments", scoped.adminToken);

    const existing = await expensesCrud.findById(id);
    if (!existing || (scoped.companyId && existing?.company_id !== scoped.companyId)) {
      return createErrorResponse({ errorMessage: "Expense not found", status: 404 });
    }

    if (existing?.expense_status === "approved" || existing?.expense_status === "paid") {
      return createErrorResponse({
        errorMessage: "Approved or paid expenses cannot be deleted",
        status: 409,
      });
    }

    const attachments = await attachmentsCrud.findMany({ expense_id: parseInt(id) });
    for (const item of attachments || []) {
      await attachmentsCrud.delete(item.id);
    }

    await expensesCrud.delete(id);
    return createSuccessResponse({ id });
  } catch (error: any) {
    console.error("Error deleting expense:", error);
    return createErrorResponse({
      errorMessage: error.message || "Failed to delete expense",
      status: error?.status || 500,
    });
  }
}, true);
