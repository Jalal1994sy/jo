
import CrudOperations from '@/lib/crud-operations';
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { requestMiddleware, parseQueryParams, validateRequestBody } from '@/lib/api-utils';
import { generateAdminUserToken } from '@/lib/auth';

const ADMIN_ROLE = 'app20251225073911jaqqaxdfir_v161_admin_user';
const USER_ROLE = 'app20251225073911jaqqaxdfir_v161_user';

// GET - Fetch all users (admin only)
export const GET = requestMiddleware(async (request, context) => {
  if (!context.payload?.isAdmin) {
    return createErrorResponse({ errorMessage: 'غير مصرح', status: 403 });
  }

  try {
    const adminToken = await generateAdminUserToken();
    const usersCrud = new CrudOperations('users', adminToken);
    const users = await usersCrud.findMany(
      {},
      { limit: 1000, offset: 0, orderBy: { column: 'created_at', direction: 'desc' } }
    );

    const safeUsers = (users || []).map((u: any) => ({
      id: u.id,
      email: u.email,
      role: u.role,
      user_type: u.user_type,
      created_at: u.created_at,
      isAdmin: u.role === process.env.SCHEMA_ADMIN_USER,
    }));

    return createSuccessResponse(safeUsers);
  } catch (error: any) {
    return createErrorResponse({ errorMessage: error.message || 'فشل تحميل المستخدمين', status: 500 });
  }
}, true);

// PUT - Update user role (admin only)
export const PUT = requestMiddleware(async (request, context) => {
  if (!context.payload?.isAdmin) {
    return createErrorResponse({ errorMessage: 'غير مصرح', status: 403 });
  }

  const { id } = parseQueryParams(request);
  if (!id) {
    return createErrorResponse({ errorMessage: 'معرف المستخدم مطلوب', status: 400 });
  }

  const body = await validateRequestBody(request);
  const { role } = body;

  if (!role) {
    return createErrorResponse({ errorMessage: 'الدور مطلوب', status: 400 });
  }

  const allowedRoles = [
    process.env.SCHEMA_ADMIN_USER || ADMIN_ROLE,
    process.env.SCHEMA_USER || USER_ROLE,
  ];

  if (!allowedRoles.includes(role)) {
    return createErrorResponse({ errorMessage: 'دور غير صالح', status: 400 });
  }

  try {
    const adminToken = await generateAdminUserToken();
    const usersCrud = new CrudOperations('users', adminToken);

    const existing = await usersCrud.findById(id);
    if (!existing) {
      return createErrorResponse({ errorMessage: 'المستخدم غير موجود', status: 404 });
    }

    // Prevent self-demotion
    if (String(existing.id) === String(context.payload?.sub) && role !== process.env.SCHEMA_ADMIN_USER) {
      return createErrorResponse({ errorMessage: 'لا يمكنك تغيير صلاحياتك الخاصة', status: 400 });
    }

    const updated = await usersCrud.update(id, { role });
    return createSuccessResponse({ id: updated.id, email: updated.email, role: updated.role });
  } catch (error: any) {
    return createErrorResponse({ errorMessage: error.message || 'فشل تحديث الصلاحيات', status: 500 });
  }
}, true);
