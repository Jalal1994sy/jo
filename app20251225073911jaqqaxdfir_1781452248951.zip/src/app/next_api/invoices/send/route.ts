
import CrudOperations from '@/lib/crud-operations';
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { requestMiddleware, validateRequestBody, getSenderEmail } from "@/lib/api-utils";
import { generateAdminUserToken } from '@/lib/auth';
import { PDFGenerator } from '@/lib/pdf-generator';
import { upload } from '@zoerai/integration';

export const POST = requestMiddleware(async (request, context) => {
  const body = await validateRequestBody(request);
  
  const { invoice_id } = body;

  if (!invoice_id) {
    return createErrorResponse({
      errorMessage: "معرف الفاتورة مطلوب",
      status: 400,
    });
  }

  try {
    const adminToken = await generateAdminUserToken();
    const invoicesCrud = new CrudOperations("invoices", adminToken);
    const companiesCrud = new CrudOperations("companies", adminToken);
    
    const invoice = await invoicesCrud.findById(invoice_id);
    if (!invoice) {
      return createErrorResponse({
        errorMessage: "الفاتورة غير موجودة",
        status: 404,
      });
    }

    if (!invoice.client_email) {
      return createErrorResponse({
        errorMessage: "لا يوجد بريد إلكتروني للعميل",
        status: 400,
      });
    }

    const issuerCompany = await companiesCrud.findById(invoice.issuer_company_id);
    
    if (!issuerCompany) {
      return createErrorResponse({
        errorMessage: "معلومات الشركة المصدرة غير موجودة",
        status: 404,
      });
    }

    let clientCompany = null;
    if (invoice.client_company_id) {
      clientCompany = await companiesCrud.findById(invoice.client_company_id);
    }
    
    const vatAmount = invoice.total_tvac - invoice.total_htva;
    
    let pdfBuffer: Buffer;
    let pdfUrl: string | null = null;
    
    if (invoice.invoice_category === 'company') {
      const items = typeof invoice.items === 'string' 
        ? JSON.parse(invoice.items) 
        : invoice.items;

      const pdfData = {
        company: {
          id: issuerCompany.id,
          name: issuerCompany.name,
          kbo_number: issuerCompany.kbo_number,
          address: issuerCompany.address,
          email: issuerCompany.email,
          phone: issuerCompany.phone,
          vat_number: issuerCompany.vat_number,
          client_name: issuerCompany.client_name,
          bank_account_iban: issuerCompany.bank_account_iban || 'BE16973450355674',
          bank_account_bic: issuerCompany.bank_account_bic || 'ARSPBE22',
          bank_account_holder: issuerCompany.bank_account_holder || issuerCompany.client_name || issuerCompany.name
        },
        client: {
          name: clientCompany ? clientCompany.client_name || clientCompany.name : invoice.client_name,
          address: clientCompany ? clientCompany.address : invoice.client_address,
          vat_number: clientCompany ? clientCompany.vat_number : invoice.client_vat,
          email: clientCompany ? clientCompany.email : invoice.client_email,
          phone: clientCompany ? clientCompany.phone : invoice.client_phone
        },
        items: items || [],
        invoiceNumber: invoice.invoice_number,
        invoiceDate: invoice.invoice_date,
        vatRate: invoice.vat_rate,
        totalHtva: invoice.total_htva,
        totalTvac: invoice.total_tvac,
        paymentReference: invoice.payment_reference || invoice.structured_reference
      };

      const pdf = PDFGenerator.generateCompanyInvoice(pdfData);
      const pdfBlob = PDFGenerator.getPDFBlob(pdf);
      const arrayBuffer = await pdfBlob.arrayBuffer();
      pdfBuffer = Buffer.from(arrayBuffer);

      try {
        const pdfFile = new File(
          [pdfBlob], 
          `Factuur-${invoice.invoice_number}.pdf`,
          { type: 'application/pdf' }
        );

        const uploadResult = await upload.uploadWithPresignedUrl(pdfFile, {
          maxSize: 5 * 1024 * 1024,
          allowedExtensions: ['.pdf']
        });

        if (uploadResult.success && uploadResult.url) {
          pdfUrl = uploadResult.url;
          console.log(`[Invoice Send] PDF uploaded successfully: ${pdfUrl}`);
          
          await invoicesCrud.update(invoice_id, {
            pdf_url: pdfUrl,
            updated_at: new Date().toISOString(),
          });
        } else {
          console.error(`[Invoice Send] PDF upload failed: ${uploadResult.error}`);
        }
      } catch (uploadError: any) {
        console.error('[Invoice Send] Error uploading PDF:', uploadError);
      }
    } else {
      return createErrorResponse({
        errorMessage: "نوع الفاتورة غير مدعوم للإرسال",
        status: 400,
      });
    }
    
    const issuerDisplayName = issuerCompany.client_name || issuerCompany.name;
    
    const invoiceLinkHtml = pdfUrl ? `
      <div style="text-align: center; margin: 30px 0;">
        <a href="${pdfUrl}" class="button" style="display: inline-block; background: linear-gradient(135deg, #2563eb 0%, #4f46e5 100%); color: white; padding: 12px 30px; border-radius: 8px; text-decoration: none; font-weight: 600;">
          Bekijk Factuur Online
        </a>
      </div>
    ` : '';
    
    const emailHtml = `
      <!DOCTYPE html>
      <html dir="ltr" lang="nl">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Factuur ${invoice.invoice_number}</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding: 40px;
            background: #f3f4f6;
            color: #333;
          }
          .email-container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
          }
          .header {
            background: linear-gradient(135deg, #2563eb 0%, #4f46e5 100%);
            color: white;
            padding: 30px;
            text-align: center;
          }
          .header h1 { font-size: 28px; margin-bottom: 10px; }
          .header p { font-size: 16px; opacity: 0.9; }
          .content { padding: 30px; }
          .greeting { font-size: 18px; margin-bottom: 20px; color: #1e293b; }
          .invoice-details {
            background: #f8fafc;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
          }
          .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #e2e8f0;
          }
          .detail-row:last-child { border-bottom: none; }
          .detail-label { color: #64748b; font-weight: 500; }
          .detail-value { color: #1e293b; font-weight: 600; }
          .total-section {
            background: #eff6ff;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
          }
          .total-row { display: flex; justify-content: space-between; padding: 8px 0; }
          .total-final {
            font-size: 24px;
            font-weight: bold;
            color: #2563eb;
            padding-top: 15px;
            border-top: 2px solid #cbd5e1;
            margin-top: 10px;
          }
          .company-info {
            background: #f1f5f9;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
            font-size: 14px;
            color: #475569;
          }
          .company-info p { margin: 5px 0; }
          .footer {
            text-align: center;
            padding: 20px;
            color: #94a3b8;
            font-size: 14px;
            border-top: 1px solid #e2e8f0;
          }
          .button {
            display: inline-block;
            background: linear-gradient(135deg, #2563eb 0%, #4f46e5 100%);
            color: white;
            padding: 12px 30px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            margin: 20px 0;
          }
        </style>
      </head>
      <body>
        <div class="email-container">
          <div class="header">
            <h1>Nieuwe Factuur</h1>
            <p>${invoice.invoice_number}</p>
          </div>
          
          <div class="content">
            <div class="greeting">
              Geachte ${invoice.client_name},
            </div>
            
            <p style="margin-bottom: 20px; color: #475569;">
              Hartelijk dank voor uw vertrouwen. Hierbij ontvangt u de factuur als bijlage.
            </p>
            
            <div class="invoice-details">
              <div class="detail-row">
                <span class="detail-label">Factuurnummer:</span>
                <span class="detail-value">${invoice.invoice_number}</span>
              </div>
              <div class="detail-row">
                <span class="detail-label">Factuurdatum:</span>
                <span class="detail-value">${new Date(invoice.invoice_date).toLocaleDateString('nl-BE')}</span>
              </div>
              ${invoice.client_vat ? `
              <div class="detail-row">
                <span class="detail-label">BTW-nummer:</span>
                <span class="detail-value">${invoice.client_vat}</span>
              </div>
              ` : ''}
            </div>
            
            <div class="total-section">
              <div class="total-row">
                <span>Bedrag excl. BTW:</span>
                <span>€${invoice.total_htva.toFixed(2)}</span>
              </div>
              <div class="total-row">
                <span>BTW (${invoice.vat_rate}%):</span>
                <span>€${vatAmount.toFixed(2)}</span>
              </div>
              <div class="total-row total-final">
                <span>Totaal bedrag:</span>
                <span>€${invoice.total_tvac.toFixed(2)}</span>
              </div>
            </div>
            
            ${invoiceLinkHtml}
            
            <div class="company-info">
              <p><strong>${issuerDisplayName}</strong></p>
              ${issuerCompany.address ? `<p>${issuerCompany.address}</p>` : ''}
              ${issuerCompany.vat_number ? `<p>BTW-nummer: ${issuerCompany.vat_number}</p>` : ''}
              ${issuerCompany.kbo_number ? `<p>KBO-nummer: ${issuerCompany.kbo_number}</p>` : ''}
              ${issuerCompany.email ? `<p>E-mail: ${issuerCompany.email}</p>` : ''}
              ${issuerCompany.phone ? `<p>Telefoon: ${issuerCompany.phone}</p>` : ''}
            </div>
            
            <p style="margin-top: 20px; color: #475569;">
              De factuur is als PDF-bestand bijgevoegd aan deze e-mail.
            </p>
            
            <p style="margin-top: 10px; color: #475569;">
              Voor vragen kunt u contact met ons opnemen.
            </p>
          </div>
          
          <div class="footer">
            <p>Bedankt voor uw vertrouwen</p>
            <p>Deze factuur is elektronisch verzonden</p>
          </div>
        </div>
      </body>
      </html>
    `;

    let emailSent = false;
    let sendError = null;

    try {
      emailSent = await sendInvoiceEmail(
        invoice.client_email, 
        invoice.invoice_number, 
        emailHtml,
        pdfBuffer
      );
    } catch (error: any) {
      console.error('Error sending invoice email:', error);
      sendError = error.message || 'فشل إرسال البريد الإلكتروني';
    }

    await invoicesCrud.update(invoice_id, {
      status: emailSent ? 'sent' : invoice.status,
      sent_at: emailSent ? new Date().toISOString() : invoice.sent_at,
      send_attempts: (invoice.send_attempts || 0) + 1,
      send_error: sendError,
      updated_at: new Date().toISOString(),
    });

    if (!emailSent) {
      return createErrorResponse({
        errorMessage: sendError || 'فشل إرسال الفاتورة',
        status: 500,
      });
    }

    return createSuccessResponse({ 
      sent: true,
      pdfUrl: pdfUrl 
    });
  } catch (error: any) {
    console.error('Error sending invoice:', error);
    return createErrorResponse({
      errorMessage: error.message || "فشل إرسال الفاتورة",
      status: 500,
    });
  }
}, true);

async function sendInvoiceEmail(
  email: string,
  invoiceNumber: string,
  htmlContent: string,
  pdfBuffer: Buffer
): Promise<boolean> {
  if (process.env.RESEND_KEY) {
    const { Resend } = await import('resend');
    const resend = new Resend(process.env.RESEND_KEY);
    
    const senderEmail = process.env.RESEND_FROM_EMAIL || "onboarding@resend.dev";

    const { error } = await resend.emails.send({
      from: senderEmail,
      to: email,
      subject: `Factuur ${invoiceNumber}`,
      html: htmlContent,
      attachments: [
        {
          filename: `Factuur-${invoiceNumber}.pdf`,
          content: pdfBuffer,
        },
      ],
    });

    if (error) {
      console.error('Resend error:', error);
      throw new Error(`Resend error: ${error.message}`);
    }

    return true;
  }

  const url = `${process.env.NEXT_PUBLIC_ZOER_HOST}/zapi/app/email/send`;

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Postgrest-API-Key": process.env.POSTGREST_API_KEY || "",
    },
    body: JSON.stringify({
      to: email,
      subject: `Factuur ${invoiceNumber}`,
      html: htmlContent,
      attachments: [
        {
          filename: `Factuur-${invoiceNumber}.pdf`,
          content: pdfBuffer.toString('base64'),
          encoding: 'base64',
          contentType: 'application/pdf'
        },
      ],
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error('Email API error:', errorText);
    throw new Error(`فشل إرسال البريد الإلكتروني: ${response.status} - ${errorText}`);
  }

  return true;
}
