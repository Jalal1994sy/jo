
import CrudOperations from '@/lib/crud-operations';
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { requestMiddleware, parseQueryParams, validateRequestBody } from "@/lib/api-utils";
import { generateAdminUserToken } from '@/lib/auth';
import { hashString } from '@/lib/server-utils';
import { getEntityDisplayName, prepareJsonbValue, prepareUpdatePayload } from '@/lib/database-json';

export const GET = requestMiddleware(async (request, context) => {
  const { limit, offset } = parseQueryParams(request);

  try {
    const adminToken = await generateAdminUserToken();
    const companiesCrud = new CrudOperations("companies", adminToken);

    const filters: Record<string, any> = {};

    if (!context.payload?.isAdmin) {
      const distributorsCrud = new CrudOperations("distributors", adminToken);
      const distributors = await distributorsCrud.findMany({
        user_id: parseInt(context.payload?.sub || '0')
      });

      if (distributors && distributors.length > 0) {
        const distributor_id = distributors[0].id;

        const distributorCompaniesCrud = new CrudOperations("distributor_companies", adminToken);
        const assignments = await distributorCompaniesCrud.findMany({
          distributor_id,
          is_active: true
        });

        if (!assignments || assignments.length === 0) {
          return createSuccessResponse([]);
        }

        const companyIds = assignments.map((assignment: any) => assignment.company_id);
        const companies = [];
        for (const companyId of companyIds) {
          const company = await companiesCrud.findById(companyId);
          if (company) {
            companies.push(company);
          }
        }

        return createSuccessResponse(companies);
      }

      return createSuccessResponse([]);
    }

    const companies = await companiesCrud.findMany(
      filters,
      {
        limit: limit > 10 ? limit : 10000,
        offset: offset || 0,
        orderBy: { column: 'created_at', direction: 'desc' }
      }
    );

    return createSuccessResponse(companies);
  } catch (error: any) {
    console.error('Error fetching companies:', error);
    return createErrorResponse({ errorMessage: error.message || "Failed to fetch companies", status: 500 });
  }
}, true);

export const POST = requestMiddleware(async (request, context) => {
  const body = await validateRequestBody(request);
  const { name, vat_number, kbo_number, address, email, phone, logo_url, password } = body;

  if (!name || !vat_number) {
    return createErrorResponse({ errorMessage: "Company name and VAT number are required", status: 400 });
  }

  if (!kbo_number) {
    return createErrorResponse({ errorMessage: "KBO number is required for Chiron submissions", status: 400 });
  }

  try {
    const adminToken = await generateAdminUserToken();
    const companiesCrud = new CrudOperations("companies", adminToken);

    let created_by_distributor_id = null;
    if (!context.payload?.isAdmin) {
      const distributorsCrud = new CrudOperations("distributors", adminToken);
      const distributors = await distributorsCrud.findMany({
        user_id: parseInt(context.payload?.sub || '0')
      });

      if (distributors && distributors.length > 0) {
        created_by_distributor_id = distributors[0].id;
      }
    }

    let password_hash = null;
    if (password && password.length >= 4) {
      password_hash = await hashString(password);
    }

    const newCompany = await companiesCrud.create({
      name,
      vat_number,
      kbo_number,
      address: address || null,
      email: email || null,
      phone: phone || null,
      logo_url: logo_url || null,
      chiron_mode: 'test',
      bank_account_iban: 'BE16973450355674',
      bank_account_bic: 'ARSPBE22',
      bank_account_holder: name,
      created_by_distributor_id,
      password_hash,
    });

    if (created_by_distributor_id) {
      const distributorCompaniesCrud = new CrudOperations("distributor_companies", adminToken);
      await distributorCompaniesCrud.create({
        distributor_id: created_by_distributor_id,
        company_id: newCompany.id,
        assigned_by_user_id: context.payload?.sub,
        is_active: true,
        notes: 'Auto-created after company creation'
      });
    }

    return createSuccessResponse(newCompany, 201);
  } catch (error: any) {
    console.error('Error creating company:', error);
    return createErrorResponse({ errorMessage: error.message || "Failed to create company", status: 500 });
  }
}, true);

export const PUT = requestMiddleware(async (request, context) => {
  const body = await validateRequestBody(request);
  const { id, password, ...rawUpdateData } = body;

  if (!id) {
    return createErrorResponse({ errorMessage: "Company id is required", status: 400 });
  }

  try {
    const adminToken = await generateAdminUserToken();
    const companiesCrud = new CrudOperations("companies", adminToken);

    const existing = await companiesCrud.findById(id);
    if (!existing) {
      return createErrorResponse({ errorMessage: "Company not found", status: 404 });
    }

    const updateData = prepareUpdatePayload(rawUpdateData);

    if (!context.payload?.isAdmin) {
      const distributorsCrud = new CrudOperations("distributors", adminToken);
      const distributors = await distributorsCrud.findMany({
        user_id: parseInt(context.payload?.sub || '0')
      });

      if (!distributors || distributors.length === 0) {
        return createErrorResponse({ errorMessage: "Access denied", status: 403 });
      }

      const distributor_id = distributors[0].id;
      const approvalRequestsCrud = new CrudOperations("approval_requests", adminToken);
      const approvalRequest = await approvalRequestsCrud.create({
        request_type: 'update',
        entity_type: 'company',
        entity_id: id,
        requested_by_user_id: context.payload?.sub,
        distributor_id,
        request_data: prepareJsonbValue(updateData),
        current_data: prepareJsonbValue(existing),
        request_reason: 'Company update request',
        status: 'pending',
        entity_name: getEntityDisplayName('company', existing),
      });

      const approvalHistoryCrud = new CrudOperations("approval_history", adminToken);
      await approvalHistoryCrud.create({
        approval_request_id: approvalRequest.id,
        action: 'submitted',
        performed_by_user_id: context.payload?.sub,
        action_notes: 'Update request submitted',
        action_data: prepareJsonbValue({
          entity_type: 'company',
          entity_id: id,
        }),
      });

      return createSuccessResponse({
        message: 'Update request sent for approval',
        approval_request_id: approvalRequest.id,
        status: 'pending_approval'
      });
    }

    if (password && password.length >= 4) {
      updateData.password_hash = await hashString(password);
    }

    if (
      typeof updateData.chiron_mode === 'string' &&
      !['test', 'production'].includes(updateData.chiron_mode)
    ) {
      return createErrorResponse({ errorMessage: "Chiron mode must be test or production", status: 400 });
    }

    const updated = await companiesCrud.update(id, {
      ...updateData,
      updated_at: new Date().toISOString(),
    });

    return createSuccessResponse(updated);
  } catch (error: any) {
    console.error('Error updating company:', error);
    return createErrorResponse({ errorMessage: error.message || "Failed to update company", status: 500 });
  }
}, true);

export const DELETE = requestMiddleware(async (request, context) => {
  const { id } = parseQueryParams(request);

  if (!id) {
    return createErrorResponse({ errorMessage: "Company id is required", status: 400 });
  }

  try {
    const adminToken = await generateAdminUserToken();
    const companiesCrud = new CrudOperations("companies", adminToken);

    const existing = await companiesCrud.findById(id);
    if (!existing) {
      return createErrorResponse({ errorMessage: "Company not found", status: 404 });
    }

    if (!context.payload?.isAdmin) {
      const distributorsCrud = new CrudOperations("distributors", adminToken);
      const distributors = await distributorsCrud.findMany({
        user_id: parseInt(context.payload?.sub || '0')
      });

      if (!distributors || distributors.length === 0) {
        return createErrorResponse({ errorMessage: "Access denied", status: 403 });
      }

      const distributor_id = distributors[0].id;
      const approvalRequestsCrud = new CrudOperations("approval_requests", adminToken);
      const approvalRequest = await approvalRequestsCrud.create({
        request_type: 'delete',
        entity_type: 'company',
        entity_id: id,
        requested_by_user_id: context.payload?.sub,
        distributor_id,
        request_data: prepareJsonbValue({}),
        current_data: prepareJsonbValue(existing),
        request_reason: 'Company delete request',
        status: 'pending',
        entity_name: getEntityDisplayName('company', existing),
      });

      const approvalHistoryCrud = new CrudOperations("approval_history", adminToken);
      await approvalHistoryCrud.create({
        approval_request_id: approvalRequest.id,
        action: 'submitted',
        performed_by_user_id: context.payload?.sub,
        action_notes: 'Delete request submitted',
        action_data: prepareJsonbValue({
          entity_type: 'company',
          entity_id: id,
        }),
      });

      return createSuccessResponse({
        message: 'Delete request sent for approval',
        approval_request_id: approvalRequest.id,
        status: 'pending_approval'
      });
    }

    await companiesCrud.delete(id);
    return createSuccessResponse({ id });
  } catch (error: any) {
    console.error('Error deleting company:', error);
    return createErrorResponse({ errorMessage: error.message || "Failed to delete company", status: 500 });
  }
}, true);
