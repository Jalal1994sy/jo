
import { requestMiddleware } from '@/lib/api-utils';
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { authCrudOperations, generateAdminUserToken } from '@/lib/auth';
import CrudOperations from '@/lib/crud-operations';

export const GET = requestMiddleware(async (request, params) => {
  try {
    if(!params.payload?.sub){
      return createErrorResponse({
        errorMessage: 'The user does not exist.',
        status: 400,
      });
    }

    const { usersCrud } = await authCrudOperations();

    const user = await usersCrud.findById(params.payload.sub);
    if (!user) {
      return createErrorResponse({
        errorMessage: 'The user does not exist.',
        status: 401,
      });
    }

    // إذا كان المستخدم موزع، جلب معلومات الموزع
    let distributorInfo = null;
    if (user.user_type === 'distributor') {
      try {
        const adminToken = await generateAdminUserToken();
        const distributorsCrud = new CrudOperations('distributors', adminToken);
        const distributors = await distributorsCrud.findMany({ user_id: user.id });
        distributorInfo = distributors?.[0] || null;
      } catch (error) {
        console.error('Error fetching distributor info:', error);
      }
    }

    const userResponse = {
      email: user.email,
      role: user.role,
      id: user.id,
      isAdmin: user.role === process.env.SCHEMA_ADMIN_USER,
      userType: user.user_type || 'admin',
      distributorInfo: distributorInfo,
    };

    return createSuccessResponse(userResponse);

  } catch (error) {
    return createErrorResponse({
      errorMessage: 'Failed to obtain user information',
      status: 500,
    });
  }
}, true);
