
import { requestMiddleware } from "@/lib/api-utils";
import { createSuccessResponse, createErrorResponse } from "@/lib/create-response";
import CrudOperations from "@/lib/crud-operations";
import { generateAdminUserToken } from "@/lib/auth";

export const GET = requestMiddleware(async () => {
  try {
    const adminToken = await generateAdminUserToken();
    const crud = new CrudOperations("privacy_policy_versions", adminToken);
    const policies = await crud.findMany({ is_current: true });
    const current = policies?.[0] || null;
    return createSuccessResponse(current);
  } catch (error: any) {
    return createErrorResponse({ errorMessage: error.message, status: 500 });
  }
}, false);
