
import { requestMiddleware } from "@/lib/api-utils";
import { createSuccessResponse, createErrorResponse } from "@/lib/create-response";
import CrudOperations from "@/lib/crud-operations";
import { generateAdminUserToken } from "@/lib/auth";

export const GET = requestMiddleware(async () => {
  try {
    const adminToken = await generateAdminUserToken();
    const crud = new CrudOperations("cookie_categories", adminToken);
    const categories = await crud.findMany({ is_active: true }, {
      orderBy: { column: "display_order", direction: "asc" },
    });
    return createSuccessResponse(categories || []);
  } catch (error: any) {
    return createErrorResponse({
      errorMessage: error.message || "Failed to fetch cookie categories",
      status: 500,
    });
  }
}, false);
