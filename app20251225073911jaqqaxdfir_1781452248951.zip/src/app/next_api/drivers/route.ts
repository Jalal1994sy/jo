
import CrudOperations from '@/lib/crud-operations';
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { requestMiddleware, parseQueryParams, validateRequestBody } from "@/lib/api-utils";
import { generateAdminUserToken } from '@/lib/auth';
import bcrypt from 'bcryptjs';
import { getEntityDisplayName, prepareJsonbValue, prepareUpdatePayload } from '@/lib/database-json';

// GET - Fetch drivers (admin sees all, distributor sees only their companies' drivers)
export const GET = requestMiddleware(async (request, context) => {
  const { limit, offset, company_id } = parseQueryParams(request);

  try {
    const adminToken = await generateAdminUserToken();
    const driversCrud = new CrudOperations("drivers", adminToken);

    const filters: Record<string, any> = {};

    if (!context.payload?.isAdmin) {
      const distributorsCrud = new CrudOperations("distributors", adminToken);
      const distributors = await distributorsCrud.findMany({
        user_id: parseInt(context.payload?.sub || '0')
      });

      if (distributors && distributors.length > 0) {
        const distributor_id = distributors[0].id;

        const distributorCompaniesCrud = new CrudOperations("distributor_companies", adminToken);
        const assignments = await distributorCompaniesCrud.findMany({
          distributor_id,
          is_active: true
        });

        if (!assignments || assignments.length === 0) {
          return createSuccessResponse([]);
        }

        const companyIds = assignments.map((assignment: any) => assignment.company_id);
        const allDrivers = [];
        for (const currentCompanyId of companyIds) {
          const companyDrivers = await driversCrud.findMany(
            { company_id: currentCompanyId },
            { limit: 10000, offset: 0 }
          );
          if (companyDrivers) {
            allDrivers.push(...companyDrivers);
          }
        }

        return createSuccessResponse(allDrivers);
      }

      return createSuccessResponse([]);
    }

    if (company_id) {
      filters.company_id = parseInt(company_id);
    }

    const drivers = await driversCrud.findMany(
      filters,
      {
        limit: limit > 10 ? limit : 10000,
        offset: offset || 0,
        orderBy: {
          column: 'created_at',
          direction: 'desc'
        }
      }
    );

    return createSuccessResponse(drivers);
  } catch (error: any) {
    console.error('Error fetching drivers:', error);
    return createErrorResponse({
      errorMessage: error.message || "Failed to fetch drivers",
      status: 500,
    });
  }
}, true);

// POST - Create new driver (admin and distributor can create)
export const POST = requestMiddleware(async (request, context) => {
  const body = await validateRequestBody(request);

  const {
    company_id,
    full_name,
    national_id,
    driver_license,
    capacity_certificate_number,
    phone,
    password
  } = body;

  if (!company_id || !full_name || !phone || !password) {
    return createErrorResponse({
      errorMessage: "Company, full name, phone and password are required",
      status: 400,
    });
  }

  try {
    const adminToken = await generateAdminUserToken();

    const companiesCrud = new CrudOperations("companies", adminToken);
    const company = await companiesCrud.findById(company_id);

    if (!company) {
      return createErrorResponse({
        errorMessage: "Company not found",
        status: 404,
      });
    }

    if (!context.payload?.isAdmin) {
      const distributorsCrud = new CrudOperations("distributors", adminToken);
      const distributors = await distributorsCrud.findMany({
        user_id: parseInt(context.payload?.sub || '0')
      });

      if (!distributors || distributors.length === 0) {
        return createErrorResponse({
          errorMessage: "Access denied",
          status: 403,
        });
      }

      const distributor_id = distributors[0].id;

      const distributorCompaniesCrud = new CrudOperations("distributor_companies", adminToken);
      const assignments = await distributorCompaniesCrud.findMany({
        distributor_id,
        company_id: parseInt(company_id),
        is_active: true
      });

      if (!assignments || assignments.length === 0) {
        return createErrorResponse({
          errorMessage: "This company is not linked to your account",
          status: 403,
        });
      }
    }

    const usersCrud = new CrudOperations("users", adminToken);
    const phoneEmail = `${phone.replace(/\s+/g, '')}@driver.local`;
    const existingUsers = await usersCrud.findMany({ email: phoneEmail });

    if (existingUsers && existingUsers.length > 0) {
      return createErrorResponse({
        errorMessage: "Phone number is already in use",
        status: 400,
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = await usersCrud.create({
      email: phoneEmail,
      password: hashedPassword,
      role: 'app20251225073911jaqqaxdfir_v1_user',
      user_type: 'driver'
    });

    let created_by_distributor_id = null;
    if (!context.payload?.isAdmin) {
      const distributorsCrud = new CrudOperations("distributors", adminToken);
      const distributors = await distributorsCrud.findMany({
        user_id: parseInt(context.payload?.sub || '0')
      });

      if (distributors && distributors.length > 0) {
        created_by_distributor_id = distributors[0].id;
      }
    }

    const driversCrud = new CrudOperations("drivers", adminToken);
    const newDriver = await driversCrud.create({
      user_id: newUser.id,
      company_id: parseInt(company_id),
      full_name,
      national_id: national_id || null,
      driver_license: driver_license || null,
      capacity_certificate_number: capacity_certificate_number || null,
      phone: phone || null,
      status: 'active',
      created_by_distributor_id
    });

    return createSuccessResponse({
      ...newDriver,
      login_phone: phone,
      login_info: `Driver can login using phone number: ${phone}`
    }, 201);
  } catch (error: any) {
    console.error('Error creating driver:', error);
    return createErrorResponse({
      errorMessage: error.message || "Failed to create driver",
      status: 500,
    });
  }
}, true);

// PUT - Update driver (requires approval for distributors)
export const PUT = requestMiddleware(async (request, context) => {
  const { id } = parseQueryParams(request);
  const body = await validateRequestBody(request);

  if (!id) {
    return createErrorResponse({
      errorMessage: "Driver id is required",
      status: 400,
    });
  }

  try {
    const adminToken = await generateAdminUserToken();
    const driversCrud = new CrudOperations("drivers", adminToken);

    const existing = await driversCrud.findById(id);
    if (!existing) {
      return createErrorResponse({
        errorMessage: "Driver not found",
        status: 404,
      });
    }

    const updateData = prepareUpdatePayload(body);

    if (!context.payload?.isAdmin) {
      const distributorsCrud = new CrudOperations("distributors", adminToken);
      const distributors = await distributorsCrud.findMany({
        user_id: parseInt(context.payload?.sub || '0')
      });

      if (!distributors || distributors.length === 0) {
        return createErrorResponse({
          errorMessage: "Access denied",
          status: 403,
        });
      }

      const distributor_id = distributors[0].id;
      const approvalRequestsCrud = new CrudOperations("approval_requests", adminToken);
      const approvalRequest = await approvalRequestsCrud.create({
        request_type: 'update',
        entity_type: 'driver',
        entity_id: id,
        requested_by_user_id: context.payload?.sub,
        distributor_id,
        request_data: prepareJsonbValue(updateData),
        current_data: prepareJsonbValue(existing),
        request_reason: 'Driver update request',
        status: 'pending',
        entity_name: getEntityDisplayName('driver', existing),
      });

      const approvalHistoryCrud = new CrudOperations("approval_history", adminToken);
      await approvalHistoryCrud.create({
        approval_request_id: approvalRequest.id,
        action: 'submitted',
        performed_by_user_id: context.payload?.sub,
        action_notes: 'Update request submitted',
        action_data: prepareJsonbValue({
          entity_type: 'driver',
          entity_id: id,
        }),
      });

      return createSuccessResponse({
        message: 'Update request sent for approval',
        approval_request_id: approvalRequest.id,
        status: 'pending_approval'
      });
    }

    if (updateData.phone && updateData.phone !== existing.phone) {
      const usersCrud = new CrudOperations("users", adminToken);
      const phoneEmail = `${String(updateData.phone).replace(/\s+/g, '')}@driver.local`;
      const existingUsers = await usersCrud.findMany({ email: phoneEmail });

      if (existingUsers && existingUsers.length > 0) {
        return createErrorResponse({
          errorMessage: "Phone number is already in use",
          status: 400,
        });
      }

      await usersCrud.update(existing.user_id, {
        email: phoneEmail
      });
    }

    if (updateData.password) {
      const usersCrud = new CrudOperations("users", adminToken);
      const hashedPassword = await bcrypt.hash(String(updateData.password), 10);
      await usersCrud.update(existing.user_id, {
        password: hashedPassword
      });
      delete updateData.password;
    }

    const updated = await driversCrud.update(id, {
      ...updateData,
      updated_at: new Date().toISOString(),
    });

    return createSuccessResponse(updated);
  } catch (error: any) {
    console.error('Error updating driver:', error);
    return createErrorResponse({
      errorMessage: error.message || "Failed to update driver",
      status: 500,
    });
  }
}, true);

// DELETE - Delete driver (requires approval for distributors)
export const DELETE = requestMiddleware(async (request, context) => {
  const { id } = parseQueryParams(request);

  if (!id) {
    return createErrorResponse({
      errorMessage: "Driver id is required",
      status: 400,
    });
  }

  try {
    const adminToken = await generateAdminUserToken();
    const driversCrud = new CrudOperations("drivers", adminToken);

    const existing = await driversCrud.findById(id);
    if (!existing) {
      return createErrorResponse({
        errorMessage: "Driver not found",
        status: 404,
      });
    }

    if (!context.payload?.isAdmin) {
      const distributorsCrud = new CrudOperations("distributors", adminToken);
      const distributors = await distributorsCrud.findMany({
        user_id: parseInt(context.payload?.sub || '0')
      });

      if (!distributors || distributors.length === 0) {
        return createErrorResponse({
          errorMessage: "Access denied",
          status: 403,
        });
      }

      const distributor_id = distributors[0].id;
      const approvalRequestsCrud = new CrudOperations("approval_requests", adminToken);
      const approvalRequest = await approvalRequestsCrud.create({
        request_type: 'delete',
        entity_type: 'driver',
        entity_id: id,
        requested_by_user_id: context.payload?.sub,
        distributor_id,
        request_data: prepareJsonbValue({}),
        current_data: prepareJsonbValue(existing),
        request_reason: 'Driver delete request',
        status: 'pending',
        entity_name: getEntityDisplayName('driver', existing),
      });

      const approvalHistoryCrud = new CrudOperations("approval_history", adminToken);
      await approvalHistoryCrud.create({
        approval_request_id: approvalRequest.id,
        action: 'submitted',
        performed_by_user_id: context.payload?.sub,
        action_notes: 'Delete request submitted',
        action_data: prepareJsonbValue({
          entity_type: 'driver',
          entity_id: id,
        }),
      });

      return createSuccessResponse({
        message: 'Delete request sent for approval',
        approval_request_id: approvalRequest.id,
        status: 'pending_approval'
      });
    }

    const usersCrud = new CrudOperations("users", adminToken);
    await usersCrud.delete(existing.user_id);
    await driversCrud.delete(id);

    return createSuccessResponse({ id });
  } catch (error: any) {
    console.error('Error deleting driver:', error);
    return createErrorResponse({
      errorMessage: error.message || "Failed to delete driver",
      status: 500,
    });
  }
}, true);
