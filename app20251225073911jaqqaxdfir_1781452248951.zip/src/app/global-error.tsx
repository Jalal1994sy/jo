"use client";

interface GlobalErrorProps {
  error: Error & { digest?: string };
  reset: () => void;
}

export default function GlobalError({ error, reset }: GlobalErrorProps) {
  return (
    <html lang="nl">
      <body className="flex min-h-screen items-center justify-center bg-background px-6 text-foreground">
        <main className="w-full max-w-lg rounded-3xl border border-border bg-card p-8 text-center shadow-sm">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-destructive/10 text-destructive">
            !
          </div>
          <h1 className="mb-2 text-2xl font-semibold">حدث خطأ غير متوقع</h1>
          <p className="mb-6 text-sm text-muted-foreground">
            تعذر إكمال العملية الحالية. يمكنك إعادة المحاولة الآن.
          </p>
          {error?.digest ? (
            <p className="mb-6 text-xs text-muted-foreground">Digest: {error.digest}</p>
          ) : null}
          <button
            onClick={() => reset()}
            className="inline-flex h-11 items-center justify-center rounded-xl bg-primary px-5 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
          >
            إعادة المحاولة
          </button>
        </main>
      </body>
    </html>
  );
}
