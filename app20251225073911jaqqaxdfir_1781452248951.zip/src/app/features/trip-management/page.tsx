
import TripManagementPage from "@/components/landing/features/TripManagementPage";

export default function Page() {
  return <TripManagementPage />;
}
