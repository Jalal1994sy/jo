

import DriverProfilePage from '@/components/driver/DriverProfilePage';

export default function DriverProfileRoute() {
  return <DriverProfilePage />;
}

