
'use client';

import { useAuth } from '@/components/auth/AuthProvider';
import { useRouter, usePathname } from 'next/navigation';
import { useEffect, useState, useCallback } from 'react';
import {
  MapPin, FileText, LogOut, Bell, MessageSquare, BarChart3, Loader2, User, TestTube,
} from 'lucide-react';
import Link from 'next/link';
import { ThemeToggle } from '@/components/ThemeToggle';
import { api } from '@/lib/api-client';
import { LanguageProvider, useLanguage } from '@/contexts/LanguageContext';
import { driverTranslations } from '@/locales/driver';
import Image from 'next/image';
import DriverSplashScreen from '@/components/DriverSplashScreen';
import VehicleSelectionModal from '@/components/VehicleSelectionModal';
import PWAInstallPrompt from '@/components/PWAInstallPrompt';

const LOGO_URL =
  'https://cdn.chat2db-ai.com/app/avatar/custom/16eda623-2b94-41ea-8390-395dcb708494_737955.png';

interface DriverInfo {
  driver: { id: number; full_name: string; phone: string; status: string; company_id: number };
  company: { id: number; name: string; chiron_mode: string };
}

interface VehicleData {
  vehicles: Array<{ id: number; brand: string; model: string; plate_number: string }>;
  current_vehicle_id: number | null;
  driver_id: number;
}

function TabItem({
  href,
  icon: Icon,
  label,
  isActive,
  badge,
}: {
  href: string;
  icon: React.ElementType;
  label: string;
  isActive: boolean;
  badge?: number;
}) {
  return (
    <Link href={href} className="dp-tab-item" data-active={isActive}>
      <div className="relative">
        <Icon
          className="w-[22px] h-[22px]"
          strokeWidth={isActive ? 2.4 : 1.8}
          aria-hidden="true"
        />
        {badge !== undefined && badge > 0 && (
          <span
            className="absolute -top-1.5 -right-2 min-w-[16px] h-[16px] px-1 rounded-full flex items-center justify-center text-[9px] font-bold text-white"
            style={{ background: 'var(--dp-danger)' }}
          >
            {badge > 9 ? '9+' : badge}
          </span>
        )}
      </div>
      <span className="dp-tab-label">{label}</span>
    </Link>
  );
}

function DriverLayoutContent({ children }: { children: React.ReactNode }) {
  const { user, isLoading, logout } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const { language, setLanguage } = useLanguage();
  const t = driverTranslations[language];
  const [driverInfo, setDriverInfo] = useState<DriverInfo | null>(null);
  const [loadingDriver, setLoadingDriver] = useState(true);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const [unreadMessages, setUnreadMessages] = useState(0);
  const [showSplash, setShowSplash] = useState(true);
  const [showVehicleSelection, setShowVehicleSelection] = useState(false);
  const [vehicleCheckDone, setVehicleCheckDone] = useState(false);

  useEffect(() => {
    if (!isLoading && !user) router.push('/driver-login');
  }, [user, isLoading, router]);

  useEffect(() => {
    const loadDriverInfo = async () => {
      if (!user) return;
      try {
        const info = await api.get<DriverInfo>('/drivers/me');
        setDriverInfo(info);
      } catch (error) {
        console.error('Error loading driver info:', error);
      } finally {
        setLoadingDriver(false);
      }
    };
    if (user) loadDriverInfo();
  }, [user]);

  useEffect(() => {
    const checkVehicleSelection = async () => {
      if (!user || showSplash || vehicleCheckDone) return;
      try {
        const data = await api.get<VehicleData>('/drivers/vehicles');
        if (data.vehicles.length > 1 && !data.current_vehicle_id) {
          setShowVehicleSelection(true);
        } else if (data.vehicles.length === 1 && !data.current_vehicle_id) {
          await api.put('/drivers/vehicles', { vehicle_id: data.vehicles[0].id });
        }
      } catch (error) {
        console.error('Error checking vehicle selection:', error);
      } finally {
        setVehicleCheckDone(true);
      }
    };
    checkVehicleSelection();
  }, [user, showSplash, vehicleCheckDone]);

  const loadUnreadCounts = useCallback(async () => {
    if (!user) return;
    try {
      const [notifications, messages] = await Promise.all([
        api.get<any[]>('/notifications/driver'),
        api.get<any[]>('/messages/driver'),
      ]);
      setUnreadNotifications(notifications.filter((n) => !n.is_read).length);
      setUnreadMessages(messages.filter((m) => !m.is_read).length);
    } catch (error) {
      console.error('Error loading counts:', error);
    }
  }, [user]);

  useEffect(() => {
    if (user) {
      loadUnreadCounts();
      const interval = setInterval(loadUnreadCounts, 60000);
      return () => clearInterval(interval);
    }
  }, [user, loadUnreadCounts]);

  const isReady = !isLoading && (!user || !loadingDriver);

  if (showSplash) {
    return <DriverSplashScreen isReady={isReady} onComplete={() => setShowSplash(false)} />;
  }

  if (!user || !driverInfo) {
    return (
      <div className="dp-root flex items-center justify-center" style={{ minHeight: '100dvh' }}>
        <Loader2 className="w-9 h-9 animate-spin" style={{ color: 'var(--dp-accent)' }} />
      </div>
    );
  }

  const totalSecondaryBadge = unreadMessages + unreadNotifications;

  // 4 main bottom tabs (Uber/Bolt style)
  const mainTabs = [
    { href: '/driver/taximeter', icon: MapPin, label: language === 'ar' ? 'الرئيسية' : language === 'fr' ? 'Accueil' : 'Home' },
    { href: '/driver/trips', icon: FileText, label: t.trips },
    { href: '/driver/summary', icon: BarChart3, label: language === 'ar' ? 'الأرباح' : language === 'fr' ? 'Revenus' : 'Earnings' },
    { href: '/driver/profile', icon: User, label: t.profile },
  ];

  const isMainTab = mainTabs.some((tab) => tab.href === pathname);

  return (
    <div className="dp-root">
      {showVehicleSelection && (
        <VehicleSelectionModal
          language={language}
          onVehicleSelected={() => setShowVehicleSelection(false)}
        />
      )}

      {/* Top Header (sticky, app-like) */}
      <header
        className="dp-app-header"
        style={{
          paddingTop: 'max(10px, env(safe-area-inset-top))',
        }}
      >
        <div className="px-4 pb-3">
          <div className="flex items-center justify-between gap-2">
            <Link
              href="/driver/profile"
              className="flex items-center gap-3 min-w-0 flex-1 active:opacity-70 transition-opacity"
              aria-label={t.myProfile}
            >
              <div
                className="relative w-9 h-9 rounded-xl overflow-hidden flex-shrink-0 dp-surface-2"
              >
                <Image
                  src={LOGO_URL}
                  alt="Jouw Driver"
                  fill
                  className="object-contain p-0.5"
                  priority
                />
              </div>
              <div className="min-w-0">
                <h1 className="text-[14px] font-bold tracking-tight truncate dp-text">
                  {driverInfo?.driver?.full_name}
                </h1>
                <div className="flex items-center gap-1.5">
                  <span
                    className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                    style={{ background: 'var(--dp-success)' }}
                  />
                  <p className="text-[11px] truncate dp-text-soft">
                    {driverInfo?.company?.name}
                  </p>
                </div>
              </div>
            </Link>

            <div className="flex items-center gap-1.5 flex-shrink-0">
              {/* Compact language toggle */}
              <div
                className="flex gap-0.5 p-0.5 rounded-xl dp-surface-2"
                role="group"
                aria-label="Language"
              >
                {(['nl', 'fr', 'ar'] as const).map((lang) => (
                  <button
                    key={lang}
                    type="button"
                    onClick={() => setLanguage(lang)}
                    className="px-2 py-1 rounded-lg text-[10.5px] font-bold transition-all"
                    style={
                      language === lang
                        ? { background: 'var(--dp-text)', color: 'var(--dp-bg)' }
                        : { color: 'var(--dp-text-muted)' }
                    }
                  >
                    {lang.toUpperCase()}
                  </button>
                ))}
              </div>

              <ThemeToggle />

              <button
                type="button"
                onClick={logout}
                className="w-9 h-9 rounded-xl flex items-center justify-center transition-colors dp-surface-2"
                title={t.logout}
                aria-label={t.logout}
              >
                <LogOut className="w-4 h-4" style={{ color: 'var(--dp-danger)' }} />
              </button>
            </div>
          </div>

          {/* Quick secondary access row */}
          <div className="flex items-center gap-2 mt-3">
            <Link
              href="/driver/messages"
              className="flex-1 dp-surface-2 rounded-xl px-3 py-2 flex items-center justify-between text-[12px] font-semibold dp-text"
              style={{ minHeight: 'auto' }}
            >
              <span className="inline-flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5" />
                {t.messages}
              </span>
              {unreadMessages > 0 && (
                <span
                  className="min-w-[18px] h-[18px] px-1 rounded-full inline-flex items-center justify-center text-[10px] font-bold text-white"
                  style={{ background: 'var(--dp-danger)' }}
                >
                  {unreadMessages > 9 ? '9+' : unreadMessages}
                </span>
              )}
            </Link>
            <Link
              href="/driver/notifications"
              className="flex-1 dp-surface-2 rounded-xl px-3 py-2 flex items-center justify-between text-[12px] font-semibold dp-text"
              style={{ minHeight: 'auto' }}
            >
              <span className="inline-flex items-center gap-1.5">
                <Bell className="w-3.5 h-3.5" />
                {t.notifications}
              </span>
              {unreadNotifications > 0 && (
                <span
                  className="min-w-[18px] h-[18px] px-1 rounded-full inline-flex items-center justify-center text-[10px] font-bold text-white"
                  style={{ background: 'var(--dp-danger)' }}
                >
                  {unreadNotifications > 9 ? '9+' : unreadNotifications}
                </span>
              )}
            </Link>
            <Link
              href="/driver/test"
              className="dp-surface-2 rounded-xl px-3 py-2 flex items-center gap-1.5 text-[12px] font-semibold dp-text"
              style={{ minHeight: 'auto' }}
            >
              <TestTube className="w-3.5 h-3.5" />
              <span>{t.test}</span>
            </Link>
          </div>
        </div>
      </header>

      {/* Main content area */}
      <main className="dp-content-with-tabbar dp-fade-in">{children}</main>

      {/* Bottom Tab Bar (Uber/Bolt style) */}
      <nav
        className="dp-tab-bar flex items-stretch"
        role="navigation"
        aria-label="Main navigation"
      >
        {mainTabs.map((tab) => (
          <TabItem
            key={tab.href}
            href={tab.href}
            icon={tab.icon}
            label={tab.label}
            isActive={pathname === tab.href}
          />
        ))}
      </nav>

      <PWAInstallPrompt />
    </div>
  );
}

export default function DriverLayout({ children }: { children: React.ReactNode }) {
  return (
    <LanguageProvider>
      <DriverLayoutContent>{children}</DriverLayoutContent>
    </LanguageProvider>
  );
}
