
import GdprAdminClient from "@/components/admin/GdprAdminClient";

export const metadata = {
  title: "GDPR & Privacy Compliance",
};

export default function GdprAdminPage() {
  return <GdprAdminClient />;
}
