
import AdminNotificationsPageClient from "@/components/admin/AdminNotificationsPageClient";

export default function AdminNotificationsPage() {
  return <AdminNotificationsPageClient />;
}
