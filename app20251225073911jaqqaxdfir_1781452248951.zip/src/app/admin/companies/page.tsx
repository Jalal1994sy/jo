
import CompaniesPageClient from "@/components/admin/CompaniesPageClient";

export default function CompaniesPage() {
  return <CompaniesPageClient />;
}
