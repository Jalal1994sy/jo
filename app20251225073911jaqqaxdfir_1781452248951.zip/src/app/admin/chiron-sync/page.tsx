
import ChironSyncPageClient from "@/components/admin/ChironSyncPageClient";

export default function ChironSyncPage() {
  return <ChironSyncPageClient />;
}
