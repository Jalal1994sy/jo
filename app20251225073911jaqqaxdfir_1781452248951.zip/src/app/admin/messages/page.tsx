
import AdminMessagesPageClient from "@/components/admin/AdminMessagesPageClient";

export default function AdminMessagesPage() {
  return <AdminMessagesPageClient />;
}
