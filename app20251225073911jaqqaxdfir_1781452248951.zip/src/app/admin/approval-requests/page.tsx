
import ApprovalRequestsPageClient from "@/components/admin/ApprovalRequestsPageClient";

export default function ApprovalRequestsPage() {
  return <ApprovalRequestsPageClient />;
}
