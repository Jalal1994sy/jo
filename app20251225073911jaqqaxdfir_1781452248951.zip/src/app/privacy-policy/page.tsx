
import { Shield, Eye, Trash2, Download, Edit, Mail, Phone } from "lucide-react";
import Link from "next/link";

export const metadata = {
  title: "Privacy Policy — Jouw Driver",
  description: "GDPR-compliant privacy policy for the Jouw Driver taxi management platform.",
};

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-8">
      <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-3">{title}</h2>
      <div className="text-slate-600 dark:text-slate-400 space-y-2 text-sm leading-relaxed">{children}</div>
    </section>
  );
}

function Right({ icon: Icon, title, desc }: { icon: React.ElementType; title: string; desc: string }) {
  return (
    <div className="flex items-start gap-3 p-4 rounded-2xl bg-blue-50 dark:bg-blue-950/30 border border-blue-100 dark:border-blue-900/30">
      <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-900/40 flex items-center justify-center flex-shrink-0">
        <Icon className="w-4 h-4 text-blue-600 dark:text-blue-400" />
      </div>
      <div>
        <p className="font-semibold text-slate-800 dark:text-slate-200 text-sm">{title}</p>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{desc}</p>
      </div>
    </div>
  );
}

export default function PrivacyPolicyPage() {
  const lastUpdated = "January 2025";

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
      <header className="sticky top-0 z-50 backdrop-blur-xl bg-white/70 dark:bg-slate-900/70 border-b border-slate-200/50 dark:border-slate-800/50">
        <div className="container mx-auto px-4 py-4 flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">Privacy Policy</h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">Last updated: {lastUpdated}</p>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-3xl">
        <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-xl p-6 sm:p-8 border border-slate-100 dark:border-slate-800">

          <Section title="1. Data Controller">
            <p>Jouw Driver BV acts as the data controller for all personal data processed through this platform. We are committed to protecting your privacy in accordance with the General Data Protection Regulation (GDPR) and Belgian law.</p>
          </Section>

          <Section title="2. Data We Collect">
            <ul className="list-disc list-inside space-y-1">
              <li><strong>Driver information:</strong> Full name, phone number, national ID, driver license number, bestuurderspas number.</li>
              <li><strong>Trip data:</strong> Start/end addresses, distance, duration, fare, timestamps, GPS coordinates.</li>
              <li><strong>Authentication data:</strong> Email address, hashed passwords, session tokens.</li>
              <li><strong>Device information:</strong> IP address, browser/app user agent, device identifiers.</li>
              <li><strong>Financial data:</strong> Invoices, payment records, tax information.</li>
            </ul>
          </Section>

          <Section title="3. Legal Basis for Processing">
            <ul className="list-disc list-inside space-y-1">
              <li><strong>Contract performance (Art. 6(1)(b)):</strong> Processing necessary to provide the taxi management service.</li>
              <li><strong>Legal obligation (Art. 6(1)(c)):</strong> Compliance with Belgian tax law and Brussels Region taxi regulations (Chiron system).</li>
              <li><strong>Legitimate interests (Art. 6(1)(f)):</strong> Platform security, fraud prevention, service improvement.</li>
              <li><strong>Consent (Art. 6(1)(a)):</strong> Analytics and marketing cookies (with your explicit consent).</li>
            </ul>
          </Section>

          <Section title="4. Data Retention">
            <ul className="list-disc list-inside space-y-1">
              <li><strong>Trip records:</strong> Retained for 7 years for tax compliance purposes.</li>
              <li><strong>Driver profiles:</strong> Retained for the duration of the service contract plus 3 years.</li>
              <li><strong>Session tokens:</strong> Expired automatically; removed within 30 days.</li>
              <li><strong>Consent records:</strong> Retained for evidence of compliance for 3 years.</li>
            </ul>
          </Section>

          <Section title="5. Third-Party Sharing">
            <p>We share your data with the following parties under strict contractual safeguards:</p>
            <ul className="list-disc list-inside space-y-1 mt-2">
              <li><strong>Chiron System (Brussels Region):</strong> Trip data is transmitted to the official Brussels taxi regulatory system as required by law.</li>
              <li><strong>Tax authorities:</strong> Financial data shared as required by Belgian law.</li>
              <li><strong>Cloud infrastructure providers:</strong> Data stored on servers within the European Economic Area (EEA).</li>
            </ul>
            <p className="mt-2">We do not sell your personal data to third parties.</p>
          </Section>

          <Section title="6. International Transfers">
            <p>All data is processed within the European Economic Area (EEA). Any transfers outside the EEA are conducted only with adequate safeguards as defined under GDPR Chapter V, including Standard Contractual Clauses (SCCs).</p>
          </Section>

          <Section title="7. Your Rights Under GDPR">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
              <Right icon={Eye} title="Right to Access (Art. 15)" desc="Request a copy of your personal data we hold." />
              <Right icon={Edit} title="Right to Rectification (Art. 16)" desc="Correct inaccurate or incomplete data." />
              <Right icon={Trash2} title="Right to Erasure (Art. 17)" desc="Request deletion of your data ('Right to be Forgotten')." />
              <Right icon={Download} title="Right to Portability (Art. 20)" desc="Receive your data in a machine-readable format." />
            </div>
            <p className="mt-4">To exercise any of these rights, submit a request through your <Link href="/driver/profile" className="text-blue-600 dark:text-blue-400 underline">driver profile page</Link> or contact us directly. We will respond within 30 days.</p>
          </Section>

          <Section title="8. Data Security">
            <p>We implement appropriate technical and organisational measures including:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>End-to-end HTTPS encryption for all data in transit.</li>
              <li>Bcrypt hashing for all passwords.</li>
              <li>JWT-based authentication with short-lived access tokens and refresh token rotation.</li>
              <li>Row-level security on all database tables.</li>
              <li>Regular security audits and access control reviews.</li>
            </ul>
          </Section>

          <Section title="9. Data Breach Notification">
            <p>In the event of a personal data breach that is likely to result in a risk to your rights and freedoms, we will notify the Belgian Data Protection Authority (Autorité de protection des données) within <strong>72 hours</strong> of becoming aware of the breach. Affected individuals will be notified without undue delay where the breach is likely to result in a high risk.</p>
          </Section>

          <Section title="10. Cookies">
            <p>We use cookies categorised as:</p>
            <ul className="list-disc list-inside space-y-1">
              <li><strong>Essential:</strong> Required for authentication and security. Cannot be disabled.</li>
              <li><strong>Analytics:</strong> Help us understand usage patterns. Requires consent.</li>
              <li><strong>Marketing:</strong> Personalised content. Requires consent.</li>
            </ul>
            <p className="mt-2">You can manage cookie preferences at any time via the cookie banner or your browser settings.</p>
          </Section>

          <Section title="11. Contact & DPO">
            <div className="flex flex-col sm:flex-row gap-3 mt-2">
              <div className="flex items-center gap-2 text-sm">
                <Mail className="w-4 h-4 text-blue-500" />
                <span>privacy@jouwdriver.be</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Phone className="w-4 h-4 text-blue-500" />
                <span>+32 2 XXX XX XX</span>
              </div>
            </div>
            <p className="mt-3 text-xs text-slate-500">You also have the right to lodge a complaint with the Belgian Data Protection Authority: <a href="https://www.dataprotectionauthority.be" target="_blank" rel="noopener noreferrer" className="text-blue-600 dark:text-blue-400 underline">www.dataprotectionauthority.be</a></p>
          </Section>

        </div>
      </main>
    </div>
  );
}
